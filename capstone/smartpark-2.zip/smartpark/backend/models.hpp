// SmartPark domain model (C++17). OOP: inheritance, polymorphism, encapsulation, vectors, file handling.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <ctime>
#include <filesystem>
#include <fstream>
#include <functional>
#include <iostream>
#include <map>
#include <memory>
#include <mutex>
#include <random>
#include <set>
#include <sstream>
#include <string>
#include <vector>
using namespace std;
typedef long long ll;

inline long TZOFF = 0;  // server local UTC offset in seconds (set in main)

// ---------- small helpers ----------
inline ll nowT() { return (ll)time(nullptr); }
inline double round2(double d) { return round(d * 100) / 100; }
inline double round1(double d) { return round(d * 10) / 10; }
inline string clean(string s) { for (char& c : s) if (c == ',' || c == '\n' || c == '\r' || c == '"' || c == '\\') c = ' '; return s; }
inline string trim(const string& s) { size_t a = s.find_first_not_of(" \t\r\n"), b = s.find_last_not_of(" \t\r\n"); return a == string::npos ? "" : s.substr(a, b - a + 1); }
inline string upper(string s) { for (char& c : s) c = (char)toupper((unsigned char)c); return s; }
inline string lower(string s) { for (char& c : s) c = (char)tolower((unsigned char)c); return s; }
inline ll toL(const string& s, ll d = 0) { try { return stoll(s); } catch (...) { return d; } }
inline double toD(const string& s, double d = 0) { try { return stod(s); } catch (...) { return d; } }
inline string jesc(const string& s) { string o; for (char c : s) { if (c == '"' || c == '\\') { o += '\\'; o += c; } else if (c == '\n') o += "\\n"; else o += c; } return o; }
inline vector<string> split(const string& s, char d = ',') { vector<string> v; string t; stringstream ss(s); while (getline(ss, t, d)) v.push_back(t); if (!s.empty() && s.back() == d) v.push_back(""); return v; }
inline string numS(double v) { if (v == floor(v) && fabs(v) < 9e15) return to_string((ll)v); char b[40]; snprintf(b, 40, "%.2f", v); return b; }
inline string tstr(ll t) { time_t x = (time_t)(t + TZOFF); tm g; gmtime_r(&x, &g); char b[24]; strftime(b, 24, "%Y-%m-%d %H:%M", &g); return b; }

// tiny JSON object builder
struct J {
  string s; bool f = true;
  J& S(const string& k, const string& v) { sep(); s += "\"" + k + "\":\"" + jesc(v) + "\""; return *this; }
  J& N(const string& k, double v) { sep(); s += "\"" + k + "\":" + numS(v); return *this; }
  J& B(const string& k, bool v) { sep(); s += "\"" + k + "\":" + (v ? "true" : "false"); return *this; }
  J& R(const string& k, const string& v) { sep(); s += "\"" + k + "\":" + v; return *this; }
  string done() const { return "{" + s + "}"; }
 private: void sep() { if (!f) s += ","; f = false; }
};
inline string arr(const vector<string>& v) { string o = "["; for (size_t i = 0; i < v.size(); i++) { if (i) o += ","; o += v[i]; } return o + "]"; }

// ---------- SHA-256 (salted + iterated for password storage) ----------
inline string sha256(const string& in) {
  static uint32_t K[64], H0[8]; static bool ready = false;
  if (!ready) {
    int c = 0;
    for (int p = 2; c < 64; p++) {
      bool pr = true; for (int d = 2; d * d <= p; d++) if (p % d == 0) pr = false;
      if (!pr) continue;
      if (c < 8) { long double r = sqrtl((long double)p); H0[c] = (uint32_t)((r - floorl(r)) * 4294967296.0L); }
      long double q = cbrtl((long double)p); K[c] = (uint32_t)((q - floorl(q)) * 4294967296.0L); c++;
    }
    ready = true;
  }
  auto R = [](uint32_t x, int n) { return (x >> n) | (x << (32 - n)); };
  uint32_t H[8]; memcpy(H, H0, sizeof H);
  string m = in; ll bits = (ll)in.size() * 8; m += (char)0x80; while (m.size() % 64 != 56) m += (char)0;
  for (int i = 7; i >= 0; i--) m += (char)((bits >> (i * 8)) & 255);
  for (size_t o = 0; o < m.size(); o += 64) {
    uint32_t w[64];
    for (int i = 0; i < 16; i++) w[i] = ((uint32_t)(uint8_t)m[o + i * 4] << 24) | ((uint32_t)(uint8_t)m[o + i * 4 + 1] << 16) | ((uint32_t)(uint8_t)m[o + i * 4 + 2] << 8) | (uint8_t)m[o + i * 4 + 3];
    for (int i = 16; i < 64; i++) { uint32_t s0 = R(w[i - 15], 7) ^ R(w[i - 15], 18) ^ (w[i - 15] >> 3), s1 = R(w[i - 2], 17) ^ R(w[i - 2], 19) ^ (w[i - 2] >> 10); w[i] = w[i - 16] + s0 + w[i - 7] + s1; }
    uint32_t a = H[0], b = H[1], c = H[2], d = H[3], e = H[4], f = H[5], g = H[6], h = H[7];
    for (int i = 0; i < 64; i++) {
      uint32_t S1 = R(e, 6) ^ R(e, 11) ^ R(e, 25), ch = (e & f) ^ (~e & g), t1 = h + S1 + ch + K[i] + w[i];
      uint32_t S0 = R(a, 2) ^ R(a, 13) ^ R(a, 22), mj = (a & b) ^ (a & c) ^ (b & c), t2 = S0 + mj;
      h = g; g = f; f = e; e = d + t1; d = c; c = b; b = a; a = t1 + t2;
    }
    H[0] += a; H[1] += b; H[2] += c; H[3] += d; H[4] += e; H[5] += f; H[6] += g; H[7] += h;
  }
  char buf[65]; for (int i = 0; i < 8; i++) snprintf(buf + i * 8, 9, "%08x", H[i]); return buf;
}
inline string hashPw(const string& salt, const string& pw) { string h = salt + pw; for (int i = 0; i < 2000; i++) h = sha256(h + salt); return h; }

// ---------- Users: User -> Customer / Admin ----------
class User {
 protected:
  string id, name, email, phone, salt, hash; bool blocked;
 public:
  User(string i, string n, string e, string p, string s, string h, bool b = false)
      : id(move(i)), name(move(n)), email(move(e)), phone(move(p)), salt(move(s)), hash(move(h)), blocked(b) {}
  virtual ~User() = default;
  virtual string getRole() const = 0;  // runtime polymorphism
  bool verify(const string& pw) const { return hashPw(salt, pw) == hash; }
  const string& getId() const { return id; }
  const string& getName() const { return name; }
  const string& getEmail() const { return email; }
  const string& getPhone() const { return phone; }
  bool isBlocked() const { return blocked; }
  void setBlocked(bool b) { blocked = b; }
  void setProfile(const string& n, const string& p) { name = n; phone = p; }
  string toCsv() const { return id + "," + name + "," + email + "," + phone + "," + salt + "," + hash + "," + getRole() + "," + (blocked ? "1" : "0"); }
};
class Customer : public User { public: using User::User; string getRole() const override { return "customer"; } };
class Admin : public User { public: using User::User; string getRole() const override { return "admin"; } };

// ---------- Rates & Vehicles: Vehicle -> Car / Bike / ElectricVehicle ----------
struct Rates {
  double car = 40, bike = 15, ev = 50, evCharge = 20, overstayPct = 50; bool manualApproval = false;
  double hourly(const string& t) const { return t == "BIKE" ? bike : t == "EV" ? ev : car; }
};
class Vehicle {
 protected:
  string id, owner, plate, model;
 public:
  Vehicle(string i, string o, string p, string m) : id(move(i)), owner(move(o)), plate(move(p)), model(move(m)) {}
  virtual ~Vehicle() = default;
  virtual string getVehicleType() const = 0;
  virtual double calculateParkingFee(double hours, const Rates& r) const = 0;
  const string& getId() const { return id; }
  const string& getOwner() const { return owner; }
  const string& getPlate() const { return plate; }
  const string& getModel() const { return model; }
  string toCsv() const { return id + "," + owner + "," + plate + "," + getVehicleType() + "," + model; }
};
class Car : public Vehicle { public: using Vehicle::Vehicle;
  string getVehicleType() const override { return "CAR"; }
  double calculateParkingFee(double h, const Rates& r) const override { return h * r.car; } };
class Bike : public Vehicle { public: using Vehicle::Vehicle;
  string getVehicleType() const override { return "BIKE"; }
  double calculateParkingFee(double h, const Rates& r) const override { return h * r.bike; } };
class ElectricVehicle : public Vehicle { public: using Vehicle::Vehicle;
  string getVehicleType() const override { return "EV"; }
  double calculateParkingFee(double h, const Rates& r) const override { return h * (r.ev + r.evCharge); } };
inline unique_ptr<Vehicle> makeVehicle(const string& t, string i = "", string o = "", string p = "", string m = "") {
  if (t == "BIKE") return make_unique<Bike>(i, o, p, m);
  if (t == "EV") return make_unique<ElectricVehicle>(i, o, p, m);
  return make_unique<Car>(i, o, p, m);
}

// ---------- Fee calculation (actual duration, 15-minute billing blocks, overstay surcharge) ----------
class FeeCalculator {
 public:
  static double billable(ll sec) { return max(1.0, ceil(sec / 900.0)) / 4.0; }
  static double overstay(const string& t, ll exitT, ll expected, const Rates& r) {
    return exitT > expected ? round2((exitT - expected) / 3600.0 * r.hourly(t) * r.overstayPct / 100.0) : 0;
  }
  static double fee(const string& t, ll entry, ll exitT, ll expected, const Rates& r) {
    auto v = makeVehicle(t);  // polymorphic call decides the per-type fee
    return round2(v->calculateParkingFee(billable(exitT - entry), r) + overstay(t, exitT, expected, r));
  }
};

// ---------- ParkingSlot & Booking (encapsulated via PROP getters/setters) ----------
#define PROP(T, n) private: T n##_{}; public: const T& n() const { return n##_; } void n(const T& v) { n##_ = v; }
class ParkingSlot {
  PROP(string, id) PROP(string, type) PROP(int, floor) PROP(string, status) PROP(string, vehicle) PROP(string, booking) PROP(string, types) PROP(bool, manual)
 public:
  ParkingSlot() { status_ = "AVAILABLE"; }
  bool supports(const string& vt) const { return types_.find(vt) != string::npos; }
  string toCsv() const { return id_ + "," + type_ + "," + to_string(floor_) + "," + status_ + "," + vehicle_ + "," + booking_ + "," + types_ + "," + (manual_ ? "1" : "0"); }
  static ParkingSlot fromCsv(const vector<string>& f) {
    ParkingSlot s; s.id(f[0]); s.type(f[1]); s.floor((int)toL(f[2])); s.status(f[3]); s.vehicle(f[4]); s.booking(f[5]); s.types(f[6]); s.manual(f[7] == "1"); return s;
  }
};
class Booking {
  PROP(string, id) PROP(string, user) PROP(string, plate) PROP(string, vtype) PROP(string, slot) PROP(string, status)
  PROP(ll, start) PROP(ll, end) PROP(ll, entry) PROP(ll, exit) PROP(ll, created) PROP(double, fee)
 public:
  string toCsv() const {
    return id_ + "," + user_ + "," + plate_ + "," + vtype_ + "," + slot_ + "," + status_ + "," + to_string(start_) + "," + to_string(end_) + "," +
           to_string(entry_) + "," + to_string(exit_) + "," + to_string(created_) + "," + numS(fee_);
  }
  static Booking fromCsv(const vector<string>& f) {
    Booking b; b.id(f[0]); b.user(f[1]); b.plate(f[2]); b.vtype(f[3]); b.slot(f[4]); b.status(f[5]); b.start(toL(f[6])); b.end(toL(f[7]));
    b.entry(toL(f[8])); b.exit(toL(f[9])); b.created(toL(f[10])); b.fee(toD(f[11])); return b;
  }
};
struct Payment { string id, booking, user, plate; double amount; ll time; };

// ---------- ParkingLot: owns the vector of slots ----------
class ParkingLot {
 public:
  vector<ParkingSlot> slots;
  ParkingSlot* find(const string& id) { for (auto& s : slots) if (s.id() == id) return &s; return nullptr; }
  bool remove(const string& id) {
    auto it = remove_if(slots.begin(), slots.end(), [&](const ParkingSlot& s) { return s.id() == id; });
    bool had = it != slots.end(); slots.erase(it, slots.end()); return had;
  }
  string nextId(const string& type) {
    string p = type == "BIKE" ? "B" : type == "EV" ? "E" : "A", id; int n = 1;
    do { id = p + (n < 10 ? "0" : "") + to_string(n++); } while (find(id));
    return id;
  }
};

// ---------- FileManager: CSV persistence via ifstream / ofstream / fstream ----------
class FileManager {
  string dir;
 public:
  explicit FileManager(const string& d) : dir(d) { error_code ec; filesystem::create_directories(d, ec); }
  bool exists(const string& f) const { return filesystem::exists(dir + "/" + f); }
  vector<vector<string>> read(const string& f) const {
    vector<vector<string>> rows; ifstream in(dir + "/" + f); if (!in) return rows;
    string l; getline(in, l);  // header
    while (getline(in, l)) { if (!l.empty() && l.back() == '\r') l.pop_back(); if (!l.empty()) rows.push_back(split(l)); }
    return rows;
  }
  bool write(const string& f, const string& header, const vector<string>& lines) const {
    string tmp = dir + "/" + f + ".tmp";
    { ofstream out(tmp); if (!out) return false; out << header << "\n"; for (auto& l : lines) out << l << "\n"; if (!out) return false; }
    error_code ec; filesystem::rename(tmp, dir + "/" + f, ec); return !ec;
  }
  bool append(const string& f, const string& header, const string& line) const {
    if (!exists(f) && !write(f, header, {})) return false;
    fstream fs(dir + "/" + f, ios::out | ios::app); if (!fs) return false; fs << line << "\n"; return (bool)fs;
  }
};

// ---------- OccupancyPredictor: rule-based, history by (weekday, hour) blended with current load ----------
struct Forecast { vector<int> hours; vector<double> pct; vector<int> peak; vector<double> profile; };
class OccupancyPredictor {
 public:
  Forecast predict(const vector<Booking>& bk, int total, double curPct, ll now) const {
    Forecast f; f.profile.assign(24, 0); if (total <= 0) return f;
    vector<double> hist(168, 0); vector<int> nd(7, 0); ll mn = now;
    for (auto& b : bk) mn = min(mn, b.start());
    for (ll d = (mn + TZOFF) / 86400; d <= (now + TZOFF) / 86400; d++) nd[(d + 4) % 7]++;  // days observed per weekday
    for (auto& b : bk) {
      if (b.status() == "CANCELLED" || b.status() == "REJECTED" || b.start() > now) continue;
      ll e = min(b.end(), b.start() + 48 * 3600);
      for (ll t = b.start() / 3600 * 3600; t < e; t += 3600) { ll lt = t + TZOFF; hist[((lt / 86400 + 4) % 7) * 24 + (lt % 86400) / 3600]++; }
    }
    for (int d = 0; d < 7; d++) for (int h = 0; h < 24; h++) hist[d * 24 + h] = nd[d] ? min(100.0, hist[d * 24 + h] / nd[d] / total * 100) : 0;
    for (int h = 0; h < 24; h++) { double s = 0; for (int d = 0; d < 7; d++) s += hist[d * 24 + h]; f.profile[h] = round1(s / 7); }
    for (int i = 0; i < 24; i++) {
      ll t = (now / 3600 + i) * 3600, lt = t + TZOFF; int dow = (int)((lt / 86400 + 4) % 7), h = (int)((lt % 86400) / 3600);
      double w = exp(-i / 4.0), base = 0.7 * hist[dow * 24 + h] + 0.3 * f.profile[h], p = w * curPct + (1 - w) * base;
      int booked = 0;
      for (auto& b : bk) if ((b.status() == "BOOKED" || b.status() == "PENDING" || b.status() == "ACTIVE") && b.start() < t + 3600 && b.end() > t) booked++;
      p = min(100.0, max(p, booked * 100.0 / total));
      f.hours.push_back(h); f.pct.push_back(round1(p));
    }
    vector<int> idx(24); for (int i = 0; i < 24; i++) idx[i] = i;
    sort(idx.begin(), idx.end(), [&](int a, int b) { return f.pct[a] > f.pct[b]; });
    for (int i = 0; i < 3; i++) f.peak.push_back(f.hours[idx[i]]);
    return f;
  }
};

// ---------- ReportGenerator: CSV text for every admin report ----------
class ReportGenerator {
 public:
  static string generate(const string& type, const vector<Booking>& bk, const vector<Payment>& pay, function<string(const string&)> nm, const Forecast& fc, ll now) {
    ostringstream o; ll dayStart = ((now + TZOFF) / 86400) * 86400 - TZOFF;
    auto row = [&](const Booking& b) {
      o << b.id() << "," << clean(nm(b.user())) << "," << b.plate() << "," << b.vtype() << "," << b.slot() << "," << b.status() << "," << tstr(b.start()) << "," << tstr(b.end()) << ","
        << (b.entry() ? tstr(b.entry()) : "") << "," << (b.exit() ? tstr(b.exit()) : "") << "," << numS(b.fee()) << "\n";
    };
    const string hdr = "booking_id,customer,plate,type,slot,status,start,end,entry,exit,fee\n";
    if (type == "daily" || type == "weekly" || type == "monthly") {
      ll span = type == "daily" ? 1 : type == "weekly" ? 7 : 30, from = dayStart - (span - 1) * 86400; double tot = 0; o << hdr;
      for (auto& b : bk) if (b.start() >= from && b.start() < dayStart + 86400) { row(b); tot += b.fee(); }
      o << "TOTAL,,,,,,,,,," << numS(round2(tot)) << "\n";
    } else if (type == "revenue") {
      double tot = 0; o << "payment_id,booking_id,customer,plate,amount,paid_at\n";
      for (auto& p : pay) { o << p.id << "," << p.booking << "," << clean(nm(p.user)) << "," << p.plate << "," << numS(p.amount) << "," << tstr(p.time) << "\n"; tot += p.amount; }
      o << "TOTAL,,,," << numS(round2(tot)) << ",\n";
    } else if (type == "entryexit") {
      o << "booking_id,plate,slot,entry,exit,duration_min\n";
      for (auto& b : bk) if (b.entry()) o << b.id() << "," << b.plate() << "," << b.slot() << "," << tstr(b.entry()) << "," << (b.exit() ? tstr(b.exit()) : "still parked") << "," << (b.exit() ? (b.exit() - b.entry()) / 60 : (now - b.entry()) / 60) << "\n";
    } else if (type == "occupancy") {
      o << "hour,historical_avg_occupancy_pct\n";
      for (int h = 0; h < 24; h++) o << h << ":00," << numS(fc.profile.empty() ? 0 : fc.profile[h]) << "\n";
      o << "\nforecast_hour,expected_occupancy_pct\n";
      for (size_t i = 0; i < fc.hours.size(); i++) o << fc.hours[i] << ":00," << numS(fc.pct[i]) << "\n";
    } else if (type == "cancellations") {
      o << hdr; for (auto& b : bk) if (b.status() == "CANCELLED" || b.status() == "REJECTED") row(b);
    } else return "";
    return o.str();
  }
};
