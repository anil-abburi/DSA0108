// ParkingManager: booking, allocation, vehicles, fees, auth, admin controls. Every mutation is validated, then persisted.
#pragma once
#include <array>
#include <iterator>
#include "models.hpp"

struct Res { int code = 200; string body; string ctype = "application/json"; };
inline Res ok(const string& b) { Res r; r.body = b; return r; }
inline Res err(const string& m, int c = 400) { Res r; r.code = c; r.body = J().S("error", m).done(); return r; }
using Params = map<string, string>;
struct Session { string uid, role; ll exp; };

class ParkingManager {
  string dir; FileManager fm;
  vector<unique_ptr<User>> users; vector<unique_ptr<Vehicle>> vehicles; ParkingLot lot;
  vector<Booking> bookings; vector<Payment> payments; Rates rates;
  map<string, Session> sessions; map<string, pair<int, ll>> fails; OccupancyPredictor predictor;
  static constexpr const char* UH = "id,name,email,phone,salt,hash,role,blocked";
  static constexpr const char* VH = "id,owner,plate,type,model";
  static constexpr const char* SH = "id,type,floor,status,vehicle,booking,types,manual";
  static constexpr const char* BH = "id,user,plate,type,slot,status,start,end,entry,exit,created,fee";
  static constexpr const char* PH = "id,booking,user,plate,amount,time";
  static constexpr const char* HH = "booking,plate,slot,entry,exit,fee";

  // ----- helpers -----
  static string rnd() { random_device rd; char b[33]; for (int i = 0; i < 4; i++) snprintf(b + i * 8, 9, "%08x", rd()); return b; }
  static bool validEmail(const string& e) { size_t a = e.find('@'); return e.size() <= 80 && a != string::npos && a > 0 && e.find('.', a) != string::npos && e.find(' ') == string::npos; }
  static bool validPhone(const string& p) { if (p.size() < 10 || p.size() > 13) return false; for (char c : p) if (!isdigit((unsigned char)c) && c != '+') return false; return true; }
  static bool strongPw(const string& p) { bool l = false, d = false; for (char c : p) { if (isalpha((unsigned char)c)) l = true; if (isdigit((unsigned char)c)) d = true; } return p.size() >= 8 && p.size() <= 64 && l && d; }
  static string normPlate(const string& p) { string o; for (char c : p) if (isalnum((unsigned char)c)) o += (char)toupper((unsigned char)c); return o; }
  static bool validType(const string& t) { return t == "CAR" || t == "BIKE" || t == "EV"; }
  template <class C, class G> static string nid(const string& p, const C& c, G g) { ll m = 0; for (auto& x : c) m = max(m, toL(g(x).substr(p.size()))); char b[24]; snprintf(b, 24, "%04lld", m + 1); return p + b; }
  User* userById(const string& id) { for (auto& u : users) if (u->getId() == id) return u.get(); return nullptr; }
  User* userByEmail(const string& e) { for (auto& u : users) if (u->getEmail() == e) return u.get(); return nullptr; }
  Vehicle* vehByPlate(const string& p) { for (auto& v : vehicles) if (v->getPlate() == p) return v.get(); return nullptr; }
  Booking* bk(const string& id) { for (auto& b : bookings) if (b.id() == id) return &b; return nullptr; }
  string custName(const string& uid) { User* u = userById(uid); return u ? u->getName() : uid; }
  static bool live(const Booking& b) { return b.status() == "BOOKED" || b.status() == "PENDING" || b.status() == "ACTIVE"; }
  static ll effEnd(const Booking& b) { return b.status() == "ACTIVE" ? max(b.end(), nowT()) : b.end(); }
  bool hasLive(const function<bool(const Booking&)>& f) { for (auto& b : bookings) if (live(b) && f(b)) return true; return false; }
  Res fin(const string& json) { return save() ? ok(json) : err("Could not save to disk. Check storage and try again.", 500); }

  // ----- persistence -----
  bool save() {
    vector<string> v; bool k = true;
    for (auto& u : users) v.push_back(u->toCsv()); k &= fm.write("users.csv", UH, v); v.clear();
    for (auto& x : vehicles) v.push_back(x->toCsv()); k &= fm.write("vehicles.csv", VH, v); v.clear();
    for (auto& s : lot.slots) v.push_back(s.toCsv()); k &= fm.write("parking_slots.csv", SH, v); v.clear();
    for (auto& b : bookings) v.push_back(b.toCsv()); k &= fm.write("bookings.csv", BH, v); v.clear();
    v = {"rate_car," + numS(rates.car), "rate_bike," + numS(rates.bike), "rate_ev," + numS(rates.ev), "ev_charge," + numS(rates.evCharge), "overstay_pct," + numS(rates.overstayPct), string("manual_approval,") + (rates.manualApproval ? "1" : "0")};
    k &= fm.write("settings.csv", "key,value", v);
    if (!k) cerr << "[error] failed writing data files\n";
    return k;
  }
  bool savePayments() {
    vector<string> p, h;
    for (auto& x : payments) p.push_back(x.id + "," + x.booking + "," + x.user + "," + x.plate + "," + numS(x.amount) + "," + to_string(x.time));
    for (auto& b : bookings) if (b.status() == "COMPLETED") h.push_back(b.id() + "," + b.plate() + "," + b.slot() + "," + to_string(b.entry()) + "," + to_string(b.exit()) + "," + numS(b.fee()));
    return fm.write("payments.csv", PH, p) & fm.write("parking_history.csv", HH, h);
  }
  void load() {
    try {
      if (!fm.exists("users.csv")) { seed(); return; }
      for (auto& f : fm.read("users.csv")) if (f.size() >= 8) {
        if (f[6] == "admin") users.push_back(make_unique<Admin>(f[0], f[1], f[2], f[3], f[4], f[5], f[7] == "1"));
        else users.push_back(make_unique<Customer>(f[0], f[1], f[2], f[3], f[4], f[5], f[7] == "1"));
      }
      for (auto& f : fm.read("vehicles.csv")) if (f.size() >= 5) vehicles.push_back(makeVehicle(f[3], f[0], f[1], f[2], f[4]));
      for (auto& f : fm.read("parking_slots.csv")) if (f.size() >= 8) lot.slots.push_back(ParkingSlot::fromCsv(f));
      for (auto& f : fm.read("bookings.csv")) if (f.size() >= 12) bookings.push_back(Booking::fromCsv(f));
      for (auto& f : fm.read("payments.csv")) if (f.size() >= 6) payments.push_back({f[0], f[1], f[2], f[3], toD(f[4]), toL(f[5])});
      for (auto& f : fm.read("settings.csv")) if (f.size() >= 2) {
        double v = toD(f[1]);
        if (f[0] == "rate_car") rates.car = v; else if (f[0] == "rate_bike") rates.bike = v; else if (f[0] == "rate_ev") rates.ev = v;
        else if (f[0] == "ev_charge") rates.evCharge = v; else if (f[0] == "overstay_pct") rates.overstayPct = v; else if (f[0] == "manual_approval") rates.manualApproval = v != 0;
      }
    } catch (const exception& e) { cerr << "[error] data load failed: " << e.what() << "\n"; }
  }
  void seed() {
    auto mk = [&](const string& n, const string& e, const string& p, const string& pw, bool adm) {
      string id = nid("U", users, [](const unique_ptr<User>& u) { return u->getId(); }), salt = rnd(), h = hashPw(salt, pw);
      if (adm) users.push_back(make_unique<Admin>(id, n, e, p, salt, h)); else users.push_back(make_unique<Customer>(id, n, e, p, salt, h));
      return id;
    };
    mk("SmartPark Admin", "admin@smartpark.com", "9000000000", "Admin@123", true);
    auto addS = [&](const char* pre, const string& type, int fl, int n) {
      for (int i = 1; i <= n; i++) { ParkingSlot s; char b[8]; snprintf(b, 8, "%s%02d", pre, i); s.id(b); s.type(type); s.floor(fl); s.types(type); lot.slots.push_back(s); }
    };
    addS("A", "CAR", 0, 8); addS("B", "BIKE", 0, 4); addS("C", "CAR", 1, 8); addS("E", "EV", 1, 4);
    save(); savePayments();
  }

  // ----- scheduling core -----
  bool slotFree(const ParkingSlot& s, ll st, ll en, const string& ignore = "") {
    if (s.status() == "DISABLED" || s.manual()) return false;
    for (auto& b : bookings) if (b.slot() == s.id() && b.id() != ignore && live(b) && b.start() < en && st < effEnd(b)) return false;
    return true;
  }
  ParkingSlot* allocate(const string& vt, ll st, ll en, int fl, const string& ig = "") {
    for (int pass = 0; pass < 2; pass++) for (auto& s : lot.slots) if ((pass == 1 || s.type() == vt) && s.supports(vt) && (fl < 0 || s.floor() == fl) && slotFree(s, st, en, ig)) return &s;
    return nullptr;
  }
  array<int, 4> counts() {
    int a = 0, o = 0, r = 0, d = 0;
    for (auto& s : lot.slots) { const string& x = s.status(); if (x == "AVAILABLE") a++; else if (x == "OCCUPIED") o++; else if (x == "RESERVED") r++; else d++; }
    return {a, o, r, d};
  }
  double occPct() { auto c = counts(); int act = c[0] + c[1] + c[2]; return act ? round1((c[1] + c[2]) * 100.0 / act) : 0; }
  double spentBy(const string& uid) { double t = 0; for (auto& p : payments) if (p.user == uid) t += p.amount; return round2(t); }

  // ----- JSON views -----
  string userJson(const User& u) { return J().S("id", u.getId()).S("name", u.getName()).S("email", u.getEmail()).S("phone", u.getPhone()).S("role", u.getRole()).B("blocked", u.isBlocked()).done(); }
  string quoteJson(const Booking& b) {
    bool done = b.status() == "COMPLETED"; ll en = b.entry() ? b.entry() : b.start();
    ll ex = done ? b.exit() : (b.status() == "ACTIVE" ? max(nowT(), en) : b.end());
    double chg = b.vtype() == "EV" ? rates.evCharge : 0, total = done ? b.fee() : FeeCalculator::fee(b.vtype(), en, ex, b.end(), rates);
    return J().N("entry", en).N("exit", ex).N("minutes", (ex - en) / 60).N("billableHours", FeeCalculator::billable(ex - en)).N("hourly", rates.hourly(b.vtype())).N("charging", chg)
        .N("overstay", FeeCalculator::overstay(b.vtype(), ex, b.end(), rates)).N("total", total).done();
  }
  string bookingJson(const Booking& b) {
    ParkingSlot* s = lot.find(b.slot());
    return J().S("id", b.id()).S("user", b.user()).S("customer", custName(b.user())).S("plate", b.plate()).S("vtype", b.vtype()).S("slot", b.slot()).N("floor", s ? s->floor() : 0)
        .S("status", b.status()).N("start", b.start()).N("end", b.end()).N("entry", b.entry()).N("exit", b.exit()).N("created", b.created()).N("fee", b.fee()).R("quote", quoteJson(b)).done();
  }
  string vehicleJson(const Vehicle& v) {
    string slot; for (auto& b : bookings) if (b.plate() == v.getPlate() && b.status() == "ACTIVE") slot = b.slot();
    int trips = 0; for (auto& b : bookings) if (b.plate() == v.getPlate() && b.status() == "COMPLETED") trips++;
    return J().S("id", v.getId()).S("plate", v.getPlate()).S("type", v.getVehicleType()).S("model", v.getModel()).S("owner", v.getOwner()).S("ownerName", custName(v.getOwner())).S("slot", slot).N("trips", trips).done();
  }
  string slotJson(const ParkingSlot& s, bool detail) {
    J j; j.S("id", s.id()).S("type", s.type()).N("floor", s.floor()).S("status", s.status()).S("types", s.types()).B("manual", s.manual());
    if (detail) { j.S("vehicle", s.vehicle()); Booking* b = bk(s.booking()); if (b) j.R("info", bookingJson(*b)); }
    return j.done();
  }
  string bookingList(vector<const Booking*> v) {
    sort(v.begin(), v.end(), [](const Booking* a, const Booking* b) { return a->start() > b->start(); });
    vector<string> o; for (auto* b : v) o.push_back(bookingJson(*b)); return arr(o);
  }
  Forecast forecast() { return predictor.predict(bookings, (int)lot.slots.size(), occPct(), nowT()); }
  string finish(Booking& b, ll ex) {
    b.exit(ex); b.fee(FeeCalculator::fee(b.vtype(), b.entry(), ex, b.end(), rates)); b.status("COMPLETED");
    Payment p{nid("P", payments, [](const Payment& x) { return x.id; }), b.id(), b.user(), b.plate(), b.fee(), ex}; payments.push_back(p);
    fm.append("payments.csv", PH, p.id + "," + p.booking + "," + p.user + "," + p.plate + "," + numS(p.amount) + "," + to_string(p.time));
    fm.append("parking_history.csv", HH, b.id() + "," + b.plate() + "," + b.slot() + "," + to_string(b.entry()) + "," + to_string(ex) + "," + numS(b.fee()));
    refresh(); return bookingJson(b);
  }

 public:
  explicit ParkingManager(const string& d) : dir(d), fm(d) { load(); }

  // Recompute derived slot status from bookings (manual admin overrides are preserved).
  void refresh() {
    ll n = nowT();
    for (auto it = sessions.begin(); it != sessions.end();) it = it->second.exp < n ? sessions.erase(it) : next(it);
    for (auto& s : lot.slots) {
      if (s.status() == "DISABLED" || s.manual()) continue;
      string st = "AVAILABLE", veh, bid;
      for (auto& b : bookings) if (b.slot() == s.id()) {
        if (b.status() == "ACTIVE") { st = "OCCUPIED"; veh = b.plate(); bid = b.id(); break; }
        if ((b.status() == "BOOKED" || b.status() == "PENDING") && b.start() <= n + 3600 && b.end() > n) { st = "RESERVED"; veh = b.plate(); bid = b.id(); }
      }
      s.status(st); s.vehicle(veh); s.booking(bid);
    }
  }
  void backup() {  // rolling snapshots (keeps the 10 most recent)
    try {
      char b[32]; time_t t = time(nullptr); tm g; localtime_r(&t, &g); strftime(b, 32, "%Y%m%d-%H%M%S", &g);
      string d = dir + "/backups/" + b; filesystem::create_directories(d);
      for (auto& e : filesystem::directory_iterator(dir)) if (e.is_regular_file() && e.path().extension() == ".csv") filesystem::copy_file(e.path(), d + "/" + e.path().filename().string());
      vector<string> ds; for (auto& e : filesystem::directory_iterator(dir + "/backups")) ds.push_back(e.path().string());
      sort(ds.begin(), ds.end()); while (ds.size() > 10) { filesystem::remove_all(ds.front()); ds.erase(ds.begin()); }
    } catch (...) { cerr << "[warn] backup failed\n"; }
  }
  void flush() { save(); savePayments(); }

  // ----- auth -----
  Res registerCustomer(Params& P) {
    string n = clean(trim(P["name"])), e = lower(trim(P["email"])), ph = trim(P["phone"]), pw = P["password"];
    if (n.size() < 2 || n.size() > 60) return err("Enter your full name");
    if (!validEmail(e)) return err("Enter a valid email address");
    if (!validPhone(ph)) return err("Phone number must be 10 to 13 digits");
    if (!strongPw(pw)) return err("Password needs 8+ characters with letters and numbers");
    if (userByEmail(e)) return err("An account with this email already exists", 409);
    string id = nid("U", users, [](const unique_ptr<User>& u) { return u->getId(); }), salt = rnd();
    users.push_back(make_unique<Customer>(id, n, e, ph, salt, hashPw(salt, pw)));
    return fin(J().S("id", id).S("message", "Account created").done());
  }
  Res login(Params& P, const string& role) {
    string em = lower(trim(P["email"])); auto& f = fails[em];
    if (f.first >= 5 && nowT() >= f.second) f.first = 0;
    if (f.first >= 5) return err("Too many attempts. Try again in a minute.", 429);
    User* u = userByEmail(em);
    if (!u || u->getRole() != role || !u->verify(P["password"])) { if (++f.first >= 5) f.second = nowT() + 60; return err("Incorrect email or password", 401); }
    if (u->isBlocked()) return err("This account is blocked. Contact the SmartPark office.", 403);
    fails.erase(em); string tok = rnd() + rnd(); sessions[tok] = {u->getId(), role, nowT() + 8 * 3600};
    return ok(J().S("token", tok).S("role", role).R("user", userJson(*u)).done());
  }
  bool auth(const string& tok, const string& role, string& uid) {
    auto it = sessions.find(tok); if (it == sessions.end() || it->second.exp < nowT() || it->second.role != role) return false;
    User* u = userById(it->second.uid); if (!u || u->isBlocked()) return false; uid = u->getId(); return true;
  }
  void logout(const string& tok) { sessions.erase(tok); }

  // ----- public -----
  Res health() { return ok(J().S("status", "ok").N("slots", (double)lot.slots.size()).N("time", (double)nowT()).done()); }
  Res publicStats(const string&, Params&) {
    auto c = counts();
    return ok(J().N("total", (double)lot.slots.size()).N("available", c[0]).N("occupied", c[1]).N("reserved", c[2]).N("disabled", c[3]).N("occupancy", occPct()).done());
  }
  Res ratesJson(const string&, Params&) {
    return ok(J().N("car", rates.car).N("bike", rates.bike).N("ev", rates.ev).N("evCharge", rates.evCharge).N("overstayPct", rates.overstayPct).B("manualApproval", rates.manualApproval).done());
  }
  Res quote(const string&, Params& P) {
    Booking b; b.vtype(validType(P["type"]) ? P["type"] : "CAR"); b.start(toL(P["start"])); b.end(toL(P["end"])); b.status("BOOKED");
    if (b.end() <= b.start()) return err("Exit must be after entry");
    return ok(quoteJson(b));
  }

  // ----- customer -----
  Res me(const string& uid, Params&) { return ok(userJson(*userById(uid))); }
  Res updateProfile(const string& uid, Params& P) {
    string n = clean(trim(P["name"])), ph = trim(P["phone"]);
    if (n.size() < 2 || n.size() > 60) return err("Enter your full name");
    if (!validPhone(ph)) return err("Phone number must be 10 to 13 digits");
    User* u = userById(uid); u->setProfile(n, ph); return fin(userJson(*u));
  }
  Res vehiclesOf(const string& uid, Params&) {
    vector<string> v; for (auto& x : vehicles) if (x->getOwner() == uid) v.push_back(vehicleJson(*x));
    return ok(J().R("vehicles", arr(v)).done());
  }
  Res vehAdd(const string& uid, Params& P) {
    string pl = normPlate(P["plate"]), t = upper(P["type"]), m = clean(trim(P["model"]));
    if (pl.size() < 4 || pl.size() > 12) return err("Registration number must be 4 to 12 letters or digits");
    if (!validType(t)) return err("Choose Car, Bike or Electric Vehicle");
    if (m.size() > 40) return err("Model name is too long");
    if (vehByPlate(pl)) return err("That registration number is already registered", 409);
    vehicles.push_back(makeVehicle(t, nid("V", vehicles, [](const unique_ptr<Vehicle>& v) { return v->getId(); }), uid, pl, m));
    return fin(vehicleJson(*vehicles.back()));
  }
  Res vehEdit(const string& uid, Params& P) {
    for (auto& v : vehicles) if (v->getId() == P["id"] && v->getOwner() == uid) {
      string pl = normPlate(P["plate"]), t = upper(P["type"]), m = clean(trim(P["model"])), old = v->getPlate();
      if (pl.size() < 4 || pl.size() > 12) return err("Registration number must be 4 to 12 letters or digits");
      if (!validType(t)) return err("Choose Car, Bike or Electric Vehicle");
      if (pl != old && vehByPlate(pl)) return err("That registration number is already registered", 409);
      if (t != v->getVehicleType() && hasLive([&](const Booking& b) { return b.plate() == old; })) return err("Cancel this vehicle's upcoming bookings before changing its type");
      for (auto& b : bookings) if (b.plate() == old) b.plate(pl);
      for (auto& p : payments) if (p.plate == old) p.plate = pl;
      v = makeVehicle(t, v->getId(), uid, pl, m);  // replace object: new dynamic type if category changed
      return fin(vehicleJson(*v));
    }
    return err("Vehicle not found", 404);
  }
  Res vehDel(const string& uid, Params& P) {
    for (size_t i = 0; i < vehicles.size(); i++) if (vehicles[i]->getId() == P["id"] && vehicles[i]->getOwner() == uid) {
      string pl = vehicles[i]->getPlate();
      if (hasLive([&](const Booking& b) { return b.plate() == pl; })) return err("This vehicle has active or upcoming bookings. Cancel them first.");
      vehicles.erase(vehicles.begin() + i); return fin("{\"ok\":true}");
    }
    return err("Vehicle not found", 404);
  }
  Res slots(const string&, Params& P) {
    string t = P["type"]; ll st = toL(P["start"]), en = toL(P["end"]); bool w = st > 0 && en > st; set<int> fl; vector<string> v;
    for (auto& s : lot.slots) {
      fl.insert(s.floor()); J j; j.S("id", s.id()).S("type", s.type()).N("floor", s.floor()).S("status", s.status()).S("types", s.types());
      if (t != "") j.B("free", s.supports(t) && (w ? slotFree(s, st, en) : s.status() == "AVAILABLE"));
      v.push_back(j.done());
    }
    vector<string> f; for (int x : fl) f.push_back(to_string(x));
    return ok(J().R("slots", arr(v)).R("floors", arr(f)).done());
  }
  Res book(const string& uid, Params& P) {
    Vehicle* v = vehByPlate(normPlate(P["plate"])); if (!v || v->getOwner() != uid) return err("Select one of your registered vehicles");
    ll st = toL(P["start"]), en = toL(P["end"]), n = nowT();
    if (st < n - 300) return err("Entry time is in the past");
    if (en <= st) return err("Exit time must be after entry time");
    if (en - st > 48 * 3600) return err("Bookings can be at most 48 hours");
    if (st > n + 90 * 86400) return err("Bookings open up to 90 days ahead");
    if (hasLive([&](const Booking& b) { return b.plate() == v->getPlate() && b.start() < en && st < effEnd(b); })) return err("This vehicle already has a booking in that period", 409);
    ParkingSlot* s = nullptr; string want = trim(P["slot"]);
    if (!want.empty()) {
      s = lot.find(want); if (!s || !s->supports(v->getVehicleType())) return err("That slot does not support this vehicle type");
      if (!slotFree(*s, st, en)) return err("That slot is not free for the selected time", 409);
    } else { string f = P["floor"]; s = allocate(v->getVehicleType(), st, en, (f.empty() || f == "any") ? -1 : (int)toL(f, -1)); }
    if (!s) return err("No suitable slot is free for that time. Try another time or floor.", 409);
    Booking b; b.id(nid("BK", bookings, [](const Booking& x) { return x.id(); })); b.user(uid); b.plate(v->getPlate()); b.vtype(v->getVehicleType()); b.slot(s->id());
    b.status(rates.manualApproval ? "PENDING" : "BOOKED"); b.start(st); b.end(en); b.created(n); bookings.push_back(b); refresh();
    return fin(bookingJson(bookings.back()));
  }
  Res myBookings(const string& uid, Params&) {
    vector<const Booking*> v; for (auto& b : bookings) if (b.user() == uid) v.push_back(&b);
    return ok(J().R("bookings", bookingList(v)).done());
  }
  Res cancel(const string& uid, Params& P, bool adm = false) {
    Booking* b = bk(P["id"]); if (!b || (!adm && b->user() != uid)) return err("Booking not found", 404);
    const string s = b->status();
    if (s == "COMPLETED") return err("Completed bookings cannot be cancelled");
    if (s == "ACTIVE") return err("The vehicle is parked. Check out instead.");
    if (s == "CANCELLED" || s == "REJECTED") return err("This booking is already closed");
    if (!adm && b->start() <= nowT()) return err("Only future bookings can be cancelled");
    b->status("CANCELLED"); refresh();
    return fin(J().S("id", b->id()).S("status", "CANCELLED").S("message", "Booking cancelled. The slot is open again for that time.").done());
  }
  Res checkin(const string& uid, Params& P, bool adm = false) {
    Booking* b = bk(P["id"]); if (!b || (!adm && b->user() != uid)) return err("Booking not found", 404);
    if (b->status() != "BOOKED") return err(b->status() == "PENDING" ? "Waiting for admin approval" : "Only confirmed bookings can check in");
    ll n = nowT(); if (n >= b->end()) return err("The booking window has ended");
    for (auto& x : bookings) if (x.plate() == b->plate() && x.status() == "ACTIVE") return err("This vehicle already has an active parking session", 409);
    ParkingSlot* s = lot.find(b->slot()); if (!s || s->status() == "DISABLED" || s->manual()) return err("The assigned slot is unavailable. Ask the admin to reassign it.", 409);
    if (n < b->start()) { if (!slotFree(*s, n, b->start(), b->id())) return err("The slot is held by another booking until your entry time", 409); b->start(n); }
    b->status("ACTIVE"); b->entry(n); refresh(); return fin(bookingJson(*b));
  }
  Res checkout(const string& uid, Params& P, bool adm = false) {
    Booking* b = bk(P["id"]); if (!b || (!adm && b->user() != uid)) return err("Booking not found", 404);
    if (b->status() != "ACTIVE") return err("No active parking session for this booking");
    ll sim = toL(P["sim_minutes"]); if (sim < 0 || sim > 7 * 24 * 60) sim = 0;
    return fin(finish(*b, sim > 0 ? b->entry() + sim * 60 : nowT()));
  }
  Res myPayments(const string& uid, Params&) {
    vector<string> v; double tot = 0;
    for (auto it = payments.rbegin(); it != payments.rend(); ++it) if (it->user == uid) { tot += it->amount; v.push_back(J().S("id", it->id).S("booking", it->booking).S("plate", it->plate).N("amount", it->amount).N("time", (double)it->time).done()); }
    return ok(J().R("payments", arr(v)).N("total", round2(tot)).done());
  }

  // ----- admin -----
  Res aOverview(const string&, Params&) {
    auto c = counts(); int cust = 0, act = 0, today = 0; double rev = 0; ll ds = ((nowT() + TZOFF) / 86400) * 86400 - TZOFF;
    for (auto& u : users) if (u->getRole() == "customer") cust++;
    for (auto& b : bookings) { if (b.status() == "ACTIVE") act++; if (b.start() >= ds && b.start() < ds + 86400 && b.status() != "CANCELLED") today++; }
    for (auto& p : payments) rev += p.amount;
    vector<string> r7; for (int i = 6; i >= 0; i--) { ll d0 = ds - i * 86400; double s = 0; for (auto& p : payments) if (p.time >= d0 && p.time < d0 + 86400) s += p.amount; r7.push_back(J().S("x", tstr(d0).substr(5, 5)).N("y", round2(s)).done()); }
    return ok(J().N("total", (double)lot.slots.size()).N("available", c[0]).N("occupied", c[1]).N("reserved", c[2]).N("disabled", c[3]).N("customers", cust).N("vehicles", (double)vehicles.size())
        .N("active", act).N("bookingsToday", today).N("revenue", round2(rev)).N("occupancy", occPct()).R("revenue7", arr(r7)).done());
  }
  Res aSlots(const string&, Params&) { vector<string> v; for (auto& s : lot.slots) v.push_back(slotJson(s, true)); return ok(J().R("slots", arr(v)).done()); }
  static string normTypes(const string& in, const string& fallback) {
    string o; for (auto& t : split(upper(in), '+')) if (validType(t) && o.find(t) == string::npos) o += (o.empty() ? "" : "+") + t;
    return o.empty() ? fallback : o;
  }
  Res aSlotAdd(const string&, Params& P) {
    string t = upper(P["type"]); ll fl = toL(P["floor"], -1);
    if (!validType(t)) return err("Choose Car, Bike or EV parking"); if (fl < 0 || fl > 20) return err("Floor must be between 0 and 20");
    ParkingSlot s; s.id(lot.nextId(t)); s.type(t); s.floor((int)fl); s.types(normTypes(P["types"], t)); lot.slots.push_back(s);
    return fin(slotJson(lot.slots.back(), true));
  }
  Res aSlotEdit(const string&, Params& P) {
    ParkingSlot* s = lot.find(P["id"]); if (!s) return err("Slot not found", 404);
    string t = upper(P["type"]); ll fl = toL(P["floor"], -1); if (!validType(t)) return err("Choose Car, Bike or EV parking"); if (fl < 0 || fl > 20) return err("Floor must be between 0 and 20");
    string types = normTypes(P["types"], t), sid = s->id(); ParkingSlot probe; probe.types(types);
    if (hasLive([&](const Booking& b) { return b.slot() == sid && !probe.supports(b.vtype()); })) return err("Existing bookings use vehicle types this change would remove");
    s->type(t); s->floor((int)fl); s->types(types); return fin(slotJson(*s, true));
  }
  Res aSlotDel(const string&, Params& P) {
    ParkingSlot* s = lot.find(P["id"]); if (!s) return err("Slot not found", 404); string sid = s->id();
    if (hasLive([&](const Booking& b) { return b.slot() == sid; })) return err("This slot has active or upcoming bookings. Cancel or move them first.");
    lot.remove(sid); return fin("{\"ok\":true}");
  }
  Res aSlotStatus(const string&, Params& P) {
    ParkingSlot* s = lot.find(P["id"]); if (!s) return err("Slot not found", 404); string st = upper(P["status"]), sid = s->id(); ll n = nowT();
    if (st == "AVAILABLE") {  // release: end any parked session, clear manual holds
      for (auto& b : bookings) if (b.slot() == sid && b.status() == "ACTIVE") finish(b, n);
      s->manual(false); s->status("AVAILABLE"); s->vehicle(""); s->booking("");
    } else if (st == "DISABLED") {
      if (hasLive([&](const Booking& b) { return b.slot() == sid; })) return err("This slot has active or upcoming bookings. Cancel or move them first.");
      s->status("DISABLED"); s->manual(false); s->vehicle(""); s->booking("");
    } else if (st == "OCCUPIED" || st == "RESERVED") {
      if (!slotFree(*s, n, n + 3600)) return err("Slot is busy or already held", 409);
      s->status(st); s->manual(true); s->vehicle(normPlate(P["vehicle"])); s->booking("");
    } else return err("Unknown status");
    refresh(); return fin(slotJson(*s, true));
  }
  Res aBookings(const string&, Params& P) {
    vector<const Booking*> v; for (auto& b : bookings) if ((P["plate"].empty() || b.plate() == normPlate(P["plate"])) && (P["user"].empty() || b.user() == P["user"])) v.push_back(&b);
    return ok(J().R("bookings", bookingList(v)).done());
  }
  Res aModify(const string&, Params& P) {
    Booking* b = bk(P["id"]); if (!b) return err("Booking not found", 404);
    if (b->status() != "BOOKED" && b->status() != "PENDING") return err("Only upcoming bookings can be modified");
    ll st = P["start"].empty() ? b->start() : toL(P["start"]), en = P["end"].empty() ? b->end() : toL(P["end"]); string sl = P["slot"].empty() ? b->slot() : P["slot"];
    if (en <= st) return err("Exit must be after entry");
    ParkingSlot* s = lot.find(sl); if (!s || !s->supports(b->vtype())) return err("That slot does not support this vehicle type");
    if (!slotFree(*s, st, en, b->id())) return err("That slot is not free for the period", 409);
    b->start(st); b->end(en); b->slot(sl); refresh(); return fin(bookingJson(*b));
  }
  Res aDecide(const string&, Params& P, bool approve) {
    Booking* b = bk(P["id"]); if (!b) return err("Booking not found", 404); if (b->status() != "PENDING") return err("Only pending bookings need a decision");
    b->status(approve ? "BOOKED" : "REJECTED"); refresh(); return fin(bookingJson(*b));
  }
  Res aVehicles(const string&, Params&) { vector<string> v; for (auto& x : vehicles) v.push_back(vehicleJson(*x)); return ok(J().R("vehicles", arr(v)).done()); }
  Res aCustomers(const string&, Params&) {
    vector<string> v;
    for (auto& u : users) if (u->getRole() == "customer") {
      int nv = 0, nb = 0; for (auto& x : vehicles) if (x->getOwner() == u->getId()) nv++; for (auto& b : bookings) if (b.user() == u->getId()) nb++;
      v.push_back(J().S("id", u->getId()).S("name", u->getName()).S("email", u->getEmail()).S("phone", u->getPhone()).B("blocked", u->isBlocked()).N("vehicles", nv).N("bookings", nb).N("spent", spentBy(u->getId())).done());
    }
    return ok(J().R("customers", arr(v)).done());
  }
  Res aCustomer(const string&, Params& P) {
    User* u = userById(P["id"]); if (!u || u->getRole() != "customer") return err("Customer not found", 404);
    vector<string> v; for (auto& x : vehicles) if (x->getOwner() == u->getId()) v.push_back(vehicleJson(*x));
    vector<const Booking*> bs; for (auto& b : bookings) if (b.user() == u->getId()) bs.push_back(&b);
    return ok(J().R("user", userJson(*u)).R("vehicles", arr(v)).R("bookings", bookingList(bs)).N("spent", spentBy(u->getId())).done());
  }
  Res aBlock(const string&, Params& P) {
    User* u = userById(P["id"]); if (!u || u->getRole() != "customer") return err("Customer not found", 404);
    bool b = P["blocked"] == "1"; u->setBlocked(b);
    if (b) for (auto it = sessions.begin(); it != sessions.end();) it = it->second.uid == u->getId() ? sessions.erase(it) : next(it);
    return fin(userJson(*u));
  }
  Res aSetRates(const string&, Params& P) {
    Rates r = rates; double* f[] = {&r.car, &r.bike, &r.ev, &r.evCharge, &r.overstayPct}; const char* k[] = {"car", "bike", "ev", "evCharge", "overstayPct"};
    for (int i = 0; i < 5; i++) if (P.count(k[i])) { double v = toD(P[k[i]], -1); if (v < 0 || v > 100000) return err(string("Invalid value for ") + k[i]); *f[i] = v; }
    if (P.count("manualApproval")) r.manualApproval = P["manualApproval"] == "1";
    rates = r; return fin(J().N("car", rates.car).N("bike", rates.bike).N("ev", rates.ev).N("evCharge", rates.evCharge).N("overstayPct", rates.overstayPct).B("manualApproval", rates.manualApproval).done());
  }
  Res aPayments(const string&, Params&) {
    vector<string> v; double tot = 0;
    for (auto it = payments.rbegin(); it != payments.rend(); ++it) { tot += it->amount; v.push_back(J().S("id", it->id).S("booking", it->booking).S("customer", custName(it->user)).S("plate", it->plate).N("amount", it->amount).N("time", (double)it->time).done()); }
    return ok(J().R("payments", arr(v)).N("total", round2(tot)).done());
  }
  Res aPredict(const string&, Params&) {
    Forecast f = forecast(); int total = (int)lot.slots.size(); vector<string> hrs, pct, av, prof, pk;
    for (size_t i = 0; i < f.hours.size(); i++) { hrs.push_back(to_string(f.hours[i])); pct.push_back(numS(f.pct[i])); av.push_back(to_string((int)round(total * (1 - f.pct[i] / 100)))); }
    for (double p : f.profile) prof.push_back(numS(p)); for (int h : f.peak) pk.push_back(to_string(h));
    return ok(J().N("total", total).N("current", occPct()).R("hours", arr(hrs)).R("pct", arr(pct)).R("available", arr(av)).R("profile", arr(prof)).R("peak", arr(pk)).done());
  }
  Res aReport(const string&, Params& P) {
    string csv = ReportGenerator::generate(P["type"], bookings, payments, [&](const string& u) { return custName(u); }, forecast(), nowT());
    if (csv.empty()) return err("Unknown report type"); Res r; r.body = csv; r.ctype = "text/csv"; return r;
  }
  Res aBackup(const string&, Params&) { flush(); backup(); return ok("{\"ok\":true}"); }
};
