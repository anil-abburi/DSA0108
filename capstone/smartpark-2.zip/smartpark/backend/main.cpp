// SmartPark REST server (cpp-httplib + C++17). Usage: ./smartpark [web_dir] [data_dir] [port]
#include <atomic>
#include <csignal>
#include <thread>
#include "httplib.h"
#include "manager.hpp"

static httplib::Server* gSrv = nullptr;
static void onSignal(int) { if (gSrv) gSrv->stop(); }

int main(int argc, char** argv) {
  string web = argc > 1 ? argv[1] : "../frontend", data = argc > 2 ? argv[2] : "./data";
  int port = argc > 3 ? atoi(argv[3]) : 8080;
  { time_t t = time(nullptr); tm l; localtime_r(&t, &l); TZOFF = l.tm_gmtoff; }

  ParkingManager PM(data); mutex M; PM.backup();
  httplib::Server svr; gSrv = &svr; signal(SIGINT, onSignal); signal(SIGTERM, onSignal);
  svr.set_payload_max_length(1 << 20);
  svr.set_default_headers({{"X-Content-Type-Options", "nosniff"}, {"X-Frame-Options", "DENY"}, {"Referrer-Policy", "no-referrer"}, {"Cache-Control", "no-store"}});
  svr.set_logger([](const httplib::Request& q, const httplib::Response& s) { if (q.path.rfind("/api", 0) == 0) cout << q.method << " " << q.path << " -> " << s.status << "\n"; });
  svr.set_exception_handler([](const httplib::Request&, httplib::Response& s, std::exception_ptr) { s.status = 500; s.set_content("{\"error\":\"Unexpected server error\"}", "application/json"); });

  // role: 0 public, 1 customer, 2 admin. Every protected route re-validates the session and role.
  auto route = [&](bool post, const string& path, int role, function<Res(const string&, Params&)> fn) {
    auto h = [&, role, fn](const httplib::Request& rq, httplib::Response& rs) {
      lock_guard<mutex> g(M);
      Params P; for (auto& p : rq.params) P[p.first] = p.second;
      string a = rq.get_header_value("Authorization"), tok = a.rfind("Bearer ", 0) == 0 ? a.substr(7) : "", uid;
      P["_token"] = tok;
      if (role && !PM.auth(tok, role == 2 ? "admin" : "customer", uid)) { rs.status = 401; rs.set_content("{\"error\":\"Please sign in again\"}", "application/json"); return; }
      PM.refresh();
      Res r; try { r = fn(uid, P); } catch (const exception& e) { r = err(string("Request failed: ") + e.what(), 500); }
      rs.status = r.code; rs.set_content(r.body, r.ctype);
    };
    post ? svr.Post(path, h) : svr.Get(path, h);
  };
#define H(m) [&](const string& u, Params& P) { return PM.m(u, P); }
#define HA(m) [&](const string& u, Params& P) { return PM.m(u, P, true); }

  // public
  route(true, "/api/register", 0, [&](const string&, Params& P) { return PM.registerCustomer(P); });
  route(true, "/api/login", 0, [&](const string&, Params& P) { return PM.login(P, "customer"); });
  route(true, "/api/admin/login", 0, [&](const string&, Params& P) { return PM.login(P, "admin"); });
  route(true, "/api/logout", 0, [&](const string&, Params& P) { PM.logout(P["_token"]); return ok("{\"ok\":true}"); });
  route(false, "/api/health", 0, [&](const string&, Params&) { return PM.health(); });
  route(false, "/api/public/stats", 0, H(publicStats));
  route(false, "/api/rates", 0, H(ratesJson));
  route(false, "/api/quote", 0, H(quote));
  // customer
  route(false, "/api/me", 1, H(me)); route(true, "/api/profile", 1, H(updateProfile));
  route(false, "/api/vehicles", 1, H(vehiclesOf)); route(true, "/api/vehicles/add", 1, H(vehAdd)); route(true, "/api/vehicles/edit", 1, H(vehEdit)); route(true, "/api/vehicles/delete", 1, H(vehDel));
  route(false, "/api/slots", 1, H(slots)); route(true, "/api/book", 1, H(book)); route(false, "/api/bookings", 1, H(myBookings));
  route(true, "/api/cancel", 1, H(cancel)); route(true, "/api/checkin", 1, H(checkin)); route(true, "/api/checkout", 1, H(checkout)); route(false, "/api/payments", 1, H(myPayments));
  // admin
  route(false, "/api/admin/overview", 2, H(aOverview)); route(false, "/api/admin/slots", 2, H(aSlots));
  route(true, "/api/admin/slot/add", 2, H(aSlotAdd)); route(true, "/api/admin/slot/edit", 2, H(aSlotEdit)); route(true, "/api/admin/slot/delete", 2, H(aSlotDel)); route(true, "/api/admin/slot/status", 2, H(aSlotStatus));
  route(false, "/api/admin/bookings", 2, H(aBookings)); route(true, "/api/admin/booking/modify", 2, H(aModify));
  route(true, "/api/admin/booking/approve", 2, [&](const string& u, Params& P) { return PM.aDecide(u, P, true); });
  route(true, "/api/admin/booking/reject", 2, [&](const string& u, Params& P) { return PM.aDecide(u, P, false); });
  route(true, "/api/admin/booking/cancel", 2, HA(cancel)); route(true, "/api/admin/booking/checkin", 2, HA(checkin)); route(true, "/api/admin/booking/checkout", 2, HA(checkout));
  route(false, "/api/admin/vehicles", 2, H(aVehicles)); route(false, "/api/admin/customers", 2, H(aCustomers)); route(false, "/api/admin/customer", 2, H(aCustomer)); route(true, "/api/admin/customer/block", 2, H(aBlock));
  route(true, "/api/admin/rates", 2, H(aSetRates)); route(false, "/api/admin/payments", 2, H(aPayments));
  route(false, "/api/admin/predict", 2, H(aPredict)); route(false, "/api/admin/report", 2, H(aReport)); route(true, "/api/admin/backup", 2, H(aBackup));

  if (!svr.set_mount_point("/", web)) { cerr << "[error] frontend folder not found: " << web << "\n"; return 1; }
  atomic<bool> run{true};  // hourly rolling backup
  thread bg([&] { for (int i = 0; run; i++) { this_thread::sleep_for(chrono::seconds(1)); if (i % 3600 == 3599) { lock_guard<mutex> g(M); PM.backup(); } } });
  cout << "SmartPark running at http://localhost:" << port << "  (data: " << data << ")\n";
  if (!svr.listen("0.0.0.0", port)) cerr << "[error] cannot bind port " << port << "\n";
  run = false; bg.join();
  { lock_guard<mutex> g(M); PM.flush(); PM.backup(); }  // graceful shutdown: flush everything to disk
  cout << "Stopped cleanly.\n"; return 0;
}
