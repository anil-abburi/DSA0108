# SmartPark: Smart Parking Slot Allocation & Vehicle Management

C++17 backend (all parking, booking, fee, prediction and persistence logic) + a React frontend with two separate portals (Customer and Admin).

## Run it

Requirements: `g++` 9+ (or clang), `make`, `curl`, Linux / macOS / WSL.

```bash
cd smartpark/backend
make            # downloads the single-header cpp-httplib once, then compiles
./smartpark ../frontend ./data 8080      # or: make run
```

Open **http://localhost:8080**. The frontend is served by the C++ server itself (no Node or Python needed). The browser loads React from a CDN, so it needs internet access once.

On first start the server creates `data/` with sample data. Stop with Ctrl+C: data is flushed and a backup is taken.

## First start (clean system)

The system starts **empty**: one admin account and 24 empty parking slots. There are no customers, vehicles, bookings or payments.

| Portal | Email | Password |
|---|---|---|
| Admin | admin@smartpark.com | Admin@123 |

Customers register themselves on the Customer Login page. Slots A01-A08 (Car, floor 0), B01-B04 (Bike, floor 0), C01-C08 (Car, floor 1) and E01-E04 (EV, floor 1) are created on first run; the admin can add, edit or delete them. Delete the `data/` folder to reset to this clean state. Analytics and forecasts fill in as real bookings happen.

## Structure

```
smartpark/
├── backend/
│   ├── models.hpp    User, Customer, Admin, Vehicle, Car, Bike, ElectricVehicle, ParkingSlot, ParkingLot,
│   │                 Booking, FeeCalculator, OccupancyPredictor, ReportGenerator, FileManager, SHA-256
│   ├── manager.hpp   ParkingManager (booking rules, allocation, auth, admin operations, persistence)
│   ├── main.cpp      HTTP routes, role guard, logging, graceful shutdown, hourly backups
│   ├── Makefile
│   └── data/         CSV files (created on first run) and backups/
└── frontend/
    ├── index.html    entry
    ├── styles.css    design system (light/dark, reduced-motion aware)
    └── app.jsx       landing, auth, customer portal, admin portal, shared components
```

## C++ class diagram

```
User (abstract: getRole())              Vehicle (abstract: getVehicleType(), calculateParkingFee())
├── Customer  -> "customer"             ├── Car             hours × car rate
└── Admin     -> "admin"                ├── Bike            hours × bike rate
                                        └── ElectricVehicle hours × (EV rate + charging)

ParkingSlot ──┐                  ParkingManager ── owns ──► vector<unique_ptr<User>>
ParkingLot ───┤ vector<ParkingSlot>                         vector<unique_ptr<Vehicle>>
Booking ──────┘                                             ParkingLot, vector<Booking>, vector<Payment>
FeeCalculator  (polymorphic fee via makeVehicle(type))      FileManager, OccupancyPredictor
OccupancyPredictor  ReportGenerator  FileManager
```

Polymorphism: `User::getRole()`, `Vehicle::getVehicleType()`, `Vehicle::calculateParkingFee()`. Memory: `unique_ptr` everywhere, so there are no leaks. Encapsulation: private fields with accessors (`PROP` macro for slots and bookings).

## Data files (`backend/data/`)

| File | Columns |
|---|---|
| users.csv | id,name,email,phone,salt,hash,role,blocked |
| vehicles.csv | id,owner,plate,type,model |
| parking_slots.csv | id,type,floor,status,vehicle,booking,types,manual |
| bookings.csv | id,user,plate,type,slot,status,start,end,entry,exit,created,fee |
| payments.csv | id,booking,user,plate,amount,time |
| parking_history.csv | booking,plate,slot,entry,exit,fee |
| settings.csv | key,value (rates, manual approval) |

Times are Unix seconds. Admin accounts live in `users.csv` with `role=admin`.

## Reliability and security

- **Atomic writes**: every file is written to `.tmp` then renamed, so a crash never leaves a half-written CSV.
- **Rolling backups**: on start, every hour, on shutdown and on demand (last 10 kept in `data/backups/`).
- **Save failures are reported** to the user instead of being silently ignored.
- **Graceful shutdown** on Ctrl+C / SIGTERM; a request mutex keeps data consistent.
- **Passwords**: random 128-bit salt + 2000 rounds of SHA-256. No plain text is stored.
- **Sessions**: random 256-bit tokens, 8-hour expiry, checked on every request; blocked users are cut off immediately.
- **Role separation**: admin and customer tokens are not interchangeable; all `/api/admin/*` routes need an admin session.
- **Login lockout**: 5 wrong passwords lock that email for 60 seconds.
- **Validation**: email, phone, password strength, plate format, time ranges, floors, rates. CSV-breaking characters are stripped.
- **Frontend**: error boundary, offline banner with auto-retry polling, skeleton loaders, reduced-motion support, keyboard focus rings.

## Business rules enforced in C++

No slot assigned twice for overlapping times; slot must support the vehicle type; vehicles can't hold two overlapping bookings or two active sessions; completed or parked bookings can't be cancelled; fees use actual duration (15-minute blocks) plus an overstay surcharge; cancelling frees the slot for that period; entry and exit update slot status; admin changes show in the customer portal within seconds (polling).

## API

All bodies are form-encoded; responses are JSON. Protected routes need `Authorization: Bearer <token>`.

**Public**: `POST /api/register` · `POST /api/login` · `POST /api/admin/login` · `POST /api/logout` · `GET /api/health` · `GET /api/public/stats` · `GET /api/rates` · `GET /api/quote?type&start&end`

**Customer**: `GET /api/me` · `POST /api/profile` · `GET /api/vehicles` · `POST /api/vehicles/add|edit|delete` · `GET /api/slots?type&start&end` · `POST /api/book` (plate,start,end,floor?,slot?) · `GET /api/bookings` · `POST /api/cancel` · `POST /api/checkin` · `POST /api/checkout` (id, sim_minutes?) · `GET /api/payments`

**Admin**: `GET /api/admin/overview|slots|bookings|vehicles|customers|customer|payments|predict|report?type=` · `POST /api/admin/slot/add|edit|delete|status` · `POST /api/admin/booking/modify|approve|reject|cancel|checkin|checkout` · `POST /api/admin/customer/block` · `POST /api/admin/rates` · `POST /api/admin/backup`

Report types: `daily weekly monthly revenue entryexit occupancy cancellations`.

## Occupancy prediction

For each of the next 24 hours: blend of current occupancy (decaying weight `e^(-i/4)`) with the historical average for that weekday and hour (70%) and the all-days hourly profile (30%), raised to at least the share of slots already booked for that hour. Peak hours are the top three predicted hours. No machine learning.
