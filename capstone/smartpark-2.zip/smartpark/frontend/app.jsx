const {useState,useEffect,useRef}=React;
const SC={AVAILABLE:'#30d158',OCCUPIED:'#ff453a',RESERVED:'#ff9f0a',DISABLED:'#8e8e93'};
const ICONS={home:'M3 11l9-8 9 8M5 10v10h14V10',search:'M11 4a7 7 0 100 14 7 7 0 000-14zM21 21l-5-5',cal:'M4 6h16v14H4zM4 10h16M8 3v4M16 3v4',car:'M5 16v-5l2-5h10l2 5v5M3 16h18M7 19v-3M17 19v-3',pin:'M12 21s7-6 7-12a7 7 0 10-14 0c0 6 7 12 7 12zM12 11a2 2 0 100-4 2 2 0 000 4z',card:'M3 6h18v12H3zM3 10h18',chart:'M4 20V10M10 20V4M16 20v-8M22 20H2',user:'M12 12a4 4 0 100-8 4 4 0 000 8zM4 21c0-4 4-6 8-6s8 2 8 6',out:'M9 4H4v16h5M16 8l4 4-4 4M20 12H9',grid:'M4 4h7v7H4zM13 4h7v7h-7zM4 13h7v7H4zM13 13h7v7h-7z',gear:'M12 15a3 3 0 100-6 3 3 0 000 6zM12 2v3M12 19v3M2 12h3M19 12h3',file:'M6 3h9l4 4v14H6zM14 3v5h5',bolt:'M13 2L4 14h7l-1 8 9-12h-7z',shield:'M12 3l8 3v6c0 5-3.5 8-8 9-4.5-1-8-4-8-9V6z',menu:'M4 7h16M4 12h16M4 17h16'};
const Icon=({n,s=20})=><svg width={s} height={s} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d={ICONS[n]}/></svg>;

/* ---------- helpers ---------- */
const $=n=>'₹'+(Math.round((+n||0)*100)/100).toLocaleString('en-IN');
const T=s=>s?new Date(s*1000).toLocaleString([],{day:'2-digit',month:'short',hour:'2-digit',minute:'2-digit'}):'—';
const dur=m=>m>=60?Math.floor(m/60)+'h '+(m%60)+'m':m+'m';
const toIn=s=>new Date(s*1000-new Date().getTimezoneOffset()*60000).toISOString().slice(0,16);
const fromIn=v=>Math.floor(new Date(v)/1000);
const pad=n=>String(n).padStart(2,'0');
const store=sessionStorage;
const auth={get token(){return store.sp_token||''},get role(){return store.sp_role||''},get user(){try{return JSON.parse(store.sp_user||'null')}catch{return null}},set(t,r,u){store.sp_token=t;store.sp_role=r;store.sp_user=JSON.stringify(u)},clear(){store.clear()}};
const toast=(m,t='ok')=>window.dispatchEvent(new CustomEvent('toast',{detail:{m,t}}));
const ask=(msg,danger)=>new Promise(res=>window.dispatchEvent(new CustomEvent('ask',{detail:{msg,danger,res}})));
async function api(method,path,params={}){
  const q=new URLSearchParams(params).toString(),o={method,headers:{}};let url=path;
  if(auth.token)o.headers.Authorization='Bearer '+auth.token;
  if(method==='GET'){if(q)url+='?'+q}else{o.body=q;o.headers['Content-Type']='application/x-www-form-urlencoded'}
  let r;try{r=await fetch(url,o);window.dispatchEvent(new CustomEvent('net',{detail:true}))}catch{window.dispatchEvent(new CustomEvent('net',{detail:false}));throw new Error('Cannot reach the SmartPark server')}
  if(r.status===401&&auth.token){const was=auth.role;auth.clear();location.hash=was==='admin'?'#/admin':'#/login';throw new Error('Your session expired. Please sign in again.')}
  if(path.includes('/report')&&r.ok)return r.blob();
  const j=await r.json().catch(()=>({error:'Unexpected server response'}));
  if(!r.ok)throw new Error(j.error||'Request failed');return j;
}
const GET=(p,q)=>api('GET',p,q),POST=(p,q)=>api('POST',p,q);
async function act(fn,okMsg){try{const r=await fn();if(okMsg)toast(okMsg);return r}catch(e){toast(e.message,'err')}}
function useData(path,q={},poll=0){
  const [d,setD]=useState(null),[e,setE]=useState('');const key=path+JSON.stringify(q);
  const load=()=>path?GET(path,q).then(x=>{setD(x);setE('')}).catch(x=>setE(x.message)):Promise.resolve();
  useEffect(()=>{setD(null);load();if(!poll||!path)return;const i=setInterval(()=>{if(!document.hidden)load()},poll);return()=>clearInterval(i)},[key]);
  return [d,load,e];
}
const csv=(rows,name)=>{const t=rows.map(r=>r.map(c=>'"'+String(c).replace(/"/g,'""')+'"').join(',')).join('\n');const a=document.createElement('a');a.href=URL.createObjectURL(new Blob([t],{type:'text/csv'}));a.download=name;a.click()};

/* ---------- shared components ---------- */
const Skel=({h=90})=><div className="sk" style={{height:h}}/>;
const Loading=({e})=>e?<div className="card"><b>Couldn't load this page.</b><p className="mut">{e}</p></div>:<div className="stack"><Skel h={110}/><Skel h={240}/></div>;
const Badge=({s})=><span className={'badge '+String(s).toLowerCase()}>{s}</span>;
const Stat=({label,value,sub})=><div className="card stat"><span>{label}</span><b>{value}</b>{sub&&<small>{sub}</small>}</div>;
const Head=({t,p,children})=><div className="pagehead"><div><h1>{t}</h1>{p&&<p>{p}</p>}</div><div className="row right">{children}</div></div>;
const Fld=({l,children})=><label className="fld"><span>{l}</span>{children}</label>;
const bind=(f,set,k)=>({value:f[k]??'',onChange:e=>set(p=>({...p,[k]:e.target.value}))});
function Modal({title,onClose,children,wide}){
  useEffect(()=>{const k=e=>e.key==='Escape'&&onClose();addEventListener('keydown',k);return()=>removeEventListener('keydown',k)},[]);
  return <div className="scrim" onClick={onClose}><div className={'modal'+(wide?' wide':'')} role="dialog" aria-modal="true" onClick={e=>e.stopPropagation()}><div className="mh"><h3>{title}</h3><button className="x" aria-label="Close" onClick={onClose}>×</button></div>{children}</div></div>;
}
function Table({cols,rows,empty='Nothing here yet.'}){return <div className="tw"><table><thead><tr>{cols.map(c=><th key={c[0]}>{c[0]}</th>)}</tr></thead><tbody>{rows.length?rows.map((r,i)=><tr key={r.id||i}>{cols.map(c=><td key={c[0]}>{c[1](r)}</td>)}</tr>):<tr><td colSpan={cols.length} className="mut">{empty}</td></tr>}</tbody></table></div>}
function Toasts(){const [l,setL]=useState([]);useEffect(()=>{const f=e=>{const id=Math.random();setL(x=>[...x,{id,...e.detail}]);setTimeout(()=>setL(x=>x.filter(y=>y.id!==id)),4200)};addEventListener('toast',f);return()=>removeEventListener('toast',f)},[]);return <div className="toasts" aria-live="polite">{l.map(t=><div key={t.id} className={'toast '+(t.t==='err'?'err':'')}>{t.m}</div>)}</div>}
function Confirm(){const [c,setC]=useState(null);useEffect(()=>{const f=e=>setC(e.detail);addEventListener('ask',f);return()=>removeEventListener('ask',f)},[]);if(!c)return null;const done=v=>{c.res(v);setC(null)};return <Modal title="Are you sure?" onClose={()=>done(false)}><p>{c.msg}</p><div className="row"><button className="btn ghost grow" onClick={()=>done(false)}>Keep it</button><button className={'btn grow '+(c.danger?'danger':'')} onClick={()=>done(true)}>Confirm</button></div></Modal>}
function Offline(){const [off,setOff]=useState(false);useEffect(()=>{const f=e=>setOff(!e.detail);addEventListener('net',f);return()=>removeEventListener('net',f)},[]);return off?<div className="banner">Connection lost. Retrying automatically…</div>:null}
const tick={cur:0};
function LineChart({data,max=100,unit='%',h=210}){const W=600,p=30,n=data.length,x=i=>p+i*(W-2*p)/Math.max(1,n-1),y=v=>h-p-(v/max)*(h-2*p),pts=data.map((d,i)=>[x(i),y(d.y)]),path=pts.map((q,i)=>(i?'L':'M')+q[0].toFixed(1)+' '+q[1].toFixed(1)).join('');
  return <svg viewBox={`0 0 ${W} ${h}`} className="chart" role="img"><defs><linearGradient id="lg" x1="0" x2="0" y1="0" y2="1"><stop offset="0" stopColor="var(--acc)" stopOpacity=".3"/><stop offset="1" stopColor="var(--acc)" stopOpacity="0"/></linearGradient></defs>{[0,.5,1].map(f=><line key={f} x1={p} x2={W-p} y1={y(max*f)} y2={y(max*f)} className="grid"/>)}<path d={path+`L${x(n-1)} ${h-p}L${x(0)} ${h-p}Z`} fill="url(#lg)"/><path d={path} className="ln"/>{pts.map((q,i)=><g key={i}><circle cx={q[0]} cy={q[1]} r="4" className="dot"/><title>{data[i].x}: {data[i].y}{unit}</title></g>)}{data.map((d,i)=>i%Math.ceil(n/8)===0&&<text key={i} x={x(i)} y={h-8} className="ax">{d.x}</text>)}</svg>}
function BarChart({data,h=210,money}){const m=Math.max(1,...data.map(d=>d.y)),W=600,p=30,bw=(W-2*p)/Math.max(1,data.length);
  return <svg viewBox={`0 0 ${W} ${h}`} className="chart" role="img">{[0,.5,1].map(f=><line key={f} x1={p} x2={W-p} y1={h-p-f*(h-2*p)} y2={h-p-f*(h-2*p)} className="grid"/>)}{data.map((d,i)=>{const bh=(d.y/m)*(h-2*p);return <g key={i}><rect x={p+i*bw+bw*.2} y={h-p-bh} width={bw*.6} height={Math.max(bh,2)} rx="6" className="bar"/><title>{d.x}: {money?$(d.y):d.y}</title><text x={p+i*bw+bw/2} y={h-8} className="ax">{d.x}</text></g>})}</svg>}
function Donut({parts}){const tot=parts.reduce((a,p)=>a+p.v,0)||1;let o=0;return <div className="donut"><svg viewBox="0 0 42 42"><circle cx="21" cy="21" r="15.9" fill="none" stroke="var(--line)" strokeWidth="5"/>{parts.map(p=>{const l=p.v/tot*100,e=<circle key={p.k} cx="21" cy="21" r="15.9" fill="none" stroke={p.c} strokeWidth="5" strokeDasharray={`${l} ${100-l}`} strokeDashoffset={25-o}/>;o+=l;return e})}</svg><ul>{parts.map(p=><li key={p.k}><i style={{background:p.c}}/>{p.k} <b>{p.v}</b></li>)}</ul></div>}
const Legend=()=><div className="legend">{Object.entries(SC).map(([k,c])=><span key={k} style={{'--c':c}}><i/>{k[0]+k.slice(1).toLowerCase()}</span>)}</div>;
const SlotCard=({s,onClick,sel,na})=><button className={'slot'+(sel?' sel':'')+(na?' na':'')} style={{'--c':SC[s.status]}} onClick={onClick} aria-label={'Slot '+s.id+' '+s.status}><b>{s.id}</b><small>{s.type==='EV'?'EV':s.type[0]+s.type.slice(1).toLowerCase()} · F{s.floor}</small><small>{s.status[0]+s.status.slice(1).toLowerCase()}</small></button>;

/* ---------- landing ---------- */
function Landing(){
  const [s]=useData('/api/public/stats',{},6000);
  const go=h=>()=>{document.body.classList.add('leave');setTimeout(()=>{location.hash=h;document.body.classList.remove('leave')},320)};
  const jump=id=>()=>document.getElementById(id).scrollIntoView({behavior:'smooth'});
  const F=[['pin','Real-time availability','Every slot, live. When the admin changes a slot, your screen updates within seconds.'],['bolt','Smart slot allocation','Pick a time and SmartPark assigns the best-fitting slot for your vehicle type, instantly.'],['cal','Easy pre-booking','Reserve ahead for any time in the next 90 days. Overlaps are blocked automatically.'],['shield','Secure vehicle management','Salted, hashed passwords, role-based access and session expiry protect every account.'],['chart','Intelligent analytics','Occupancy forecasts and peak hours, calculated from your own parking history.'],['card','Fair, exact fees','Billed by the 15 minutes you actually park, with clear per-type rates.']];
  return <div>
    <nav className="topnav glass"><b className="logo" style={{padding:0}}><i>P</i>SmartPark</b><div><a onClick={jump('how')}>How it works</a><a onClick={jump('features')}>Features</a><button className="btn ghost sm" onClick={go('/admin')}>Admin Login</button><button className="btn sm" onClick={go('/login')}>Customer Login</button></div></nav>
    <header className="hero">
      <div className="live"><span className="pulse"/>{s?`${s.available} of ${s.total} spots open · ${s.occupancy}% full`:'Checking live availability…'}</div>
      <h1>Parking, Perfected.</h1><p>Find your space. Reserve your spot. Move smarter.</p>
      <div className="row" style={{justifyContent:'center'}}><button className="btn" onClick={go('/login')}>Find Parking</button><button className="btn ghost" style={{color:'#fff',background:'rgba(255,255,255,.12)'}} onClick={go('/login')}>Customer Login</button><button className="btn ghost" style={{color:'#fff',background:'rgba(255,255,255,.12)'}} onClick={go('/admin')}>Admin Login</button></div>
      <div className="lot" aria-hidden="true">{Array.from({length:16},(_,i)=><div key={i} className="ps"><i className={'car'+(i%5===2?' r':'')} style={{'--d':((i*1.37)%7).toFixed(2)+'s'}}/></div>)}</div>
    </header>
    <section className="sec" id="features"><h2>Everything a lot needs. Nothing it doesn't.</h2><p>One calm interface for drivers and operators, powered by a C++ engine.</p><div className="feat">{F.map(f=><div key={f[1]} className="card"><div className="ic"><Icon n={f[0]} s={22}/></div><h3>{f[1]}</h3><p>{f[2]}</p></div>)}</div></section>
    <div className="dark" id="how"><section className="sec"><h2>How SmartPark works</h2><p>From search to exit in three steps.</p><div className="steps"><div><b>Add your vehicle</b><span>Register a car, bike or EV once. Edit it any time.</span></div><div><b>Choose a time</b><span>Pick a date, entry and exit. See free slots for that exact window.</span></div><div><b>Park and go</b><span>Check in at the gate, check out when you leave, and pay for exactly what you used.</span></div></div></section></div>
    <section className="sec"><h2>Why SmartPark?</h2><p>No double bookings, no surprise fees, no guesswork.</p><div className="cards"><Stat label="Double bookings" value="0" sub="Overlaps are rejected by the engine"/><Stat label="Billing precision" value="15 min" sub="Charged by actual duration"/><Stat label="Booking window" value="90 days" sub="Pre-book well ahead"/><Stat label="Updates" value="Live" sub="Admin changes show instantly"/></div></section>
    <footer><div><b className="logo" style={{padding:0}}><i>P</i>SmartPark</b><p>Smart Parking Slot Allocation &amp; Vehicle Management</p></div><div><b>Contact</b><p>support@smartpark.example<br/>+91 90000 00000<br/>Open 24 hours</p></div><div><b>Portals</b><p><a onClick={go('/login')}>Customer</a><br/><a onClick={go('/admin')}>Admin</a></p></div></footer>
  </div>;
}

/* ---------- auth screens ---------- */
function AuthCard({admin}){
  const [mode,setMode]=useState(admin||localStorage.sp_seen?'in':'up'),[busy,setBusy]=useState(false);
  const [f,setF]=useState(mode==='up'?{name:'',email:'',phone:'',password:''}:{email:'',password:''});
  const submit=async e=>{e.preventDefault();setBusy(true);
    try{if(mode==='up'){await POST('/api/register',f);toast('Account created')}
      const r=await POST(admin?'/api/admin/login':'/api/login',{email:f.email,password:f.password});localStorage.sp_seen='1';auth.set(r.token,r.role,r.user);location.hash=admin?'#/console/overview':'#/portal/dashboard'}
    catch(x){toast(x.message,'err')}setBusy(false)};
  const swap=m=>{setMode(m);setF(m==='up'?{name:'',email:'',phone:'',password:''}:{email:'',password:''})};
  return <div className="auth"><form className="card" onSubmit={submit}>
    <a onClick={()=>location.hash='#/'} className="mut">← SmartPark</a><h1>{admin?'Admin sign in':mode==='in'?'Welcome back':'Create your account'}</h1>
    {mode==='up'&&<><Fld l="Full name"><input {...bind(f,setF,'name')} required autoComplete="name"/></Fld><Fld l="Phone number"><input {...bind(f,setF,'phone')} required inputMode="tel" placeholder="9876543210"/></Fld></>}
    <Fld l="Email"><input type="email" {...bind(f,setF,'email')} required autoComplete="email"/></Fld>
    <Fld l="Password"><input type="password" {...bind(f,setF,'password')} required autoComplete={mode==='up'?'new-password':'current-password'}/></Fld>
    <button className="btn" disabled={busy}>{busy?'Please wait…':mode==='up'?'Create account':'Sign in'}</button>
    {!admin&&<p className="mut" style={{textAlign:'center'}}>{mode==='in'?<>New here? <a onClick={()=>swap('up')}>Create an account</a></>:<>Have an account? <a onClick={()=>swap('in')}>Sign in</a></>}</p>}
  </form></div>;
}

/* ---------- customer pages ---------- */
function Dash({go}){
  const [b]=useData('/api/bookings',{},8000),[v]=useData('/api/vehicles'),[s]=useData('/api/public/stats',{},8000),[p]=useData('/api/payments');
  if(!b||!v||!s||!p)return <Loading/>;
  const act=b.bookings.find(x=>x.status==='ACTIVE'),up=b.bookings.filter(x=>x.status==='BOOKED'||x.status==='PENDING').sort((a,c)=>a.start-c.start);
  return <div className="stack"><Head t={'Hello, '+auth.user.name.split(' ')[0]} p="Here's your parking at a glance."><button className="btn" onClick={()=>go('find')}>Find parking</button></Head>
    <div className="cards"><Stat label="Open slots now" value={s.available} sub={`of ${s.total}`}/><Stat label="Registered vehicles" value={v.vehicles.length}/><Stat label="Upcoming reservations" value={up.length}/><Stat label="Total parking spend" value={$(p.total)}/></div>
    <div className="two"><div className="card"><h2>Current parking</h2>{act?<dl className="kv"><dt>Slot</dt><dd>{act.slot} · Floor {act.floor}</dd><dt>Vehicle</dt><dd>{act.plate}</dd><dt>Entered</dt><dd>{T(act.entry)}</dd><dt>Fee so far</dt><dd>{$(act.quote.total)}</dd></dl>:<p className="mut">You're not parked right now.</p>}{act&&<button className="btn sm" style={{marginTop:16}} onClick={()=>go('tracking')}>Open tracking</button>}</div>
    <div className="card"><h2>Next reservation</h2>{up[0]?<dl className="kv"><dt>Booking</dt><dd>{up[0].id}</dd><dt>Slot</dt><dd>{up[0].slot}</dd><dt>Vehicle</dt><dd>{up[0].plate}</dd><dt>Arrive</dt><dd>{T(up[0].start)}</dd><dt>Status</dt><dd><Badge s={up[0].status}/></dd></dl>:<p className="mut">No upcoming reservations.</p>}</div></div>
    <div className="card"><h2>Recent bookings</h2><Table cols={[['Booking',r=>r.id],['Vehicle',r=>r.plate],['Slot',r=>r.slot],['When',r=>T(r.start)],['Status',r=>r.status&&<Badge s={r.status}/>]]} rows={b.bookings.slice(0,5)}/></div></div>;
}
function Find({go}){
  const now=new Date(),h1=new Date(now.getTime()+3600e3);
  const [veh]=useData('/api/vehicles'),[f,setF]=useState({plate:'',floor:'any',slot:'',date:`${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())}`,t1:`${pad(h1.getHours())}:00`,t2:`${pad((h1.getHours()+2)%24)}:00`}),[done,setDone]=useState(null),[busy,setBusy]=useState(false);
  useEffect(()=>{if(veh&&!f.plate&&veh.vehicles[0])setF(p=>({...p,plate:veh.vehicles[0].plate}))},[veh]);
  const v=veh?.vehicles.find(x=>x.plate===f.plate),st=Math.floor(new Date(f.date+'T'+f.t1)/1000),en=Math.floor(new Date(f.date+'T'+f.t2)/1000),valid=v&&st&&en>st;
  const [sl]=useData(v?'/api/slots':null,v?{type:v.type,...(valid?{start:st,end:en}:{})}:{},valid?8000:0),[q]=useData(valid?'/api/quote':null,valid?{type:v.type,start:st,end:en}:{});
  const book=async()=>{setBusy(true);const r=await act(()=>POST('/api/book',{plate:f.plate,start:st,end:en,floor:f.floor,slot:f.slot}));setBusy(false);if(r)setDone(r)};
  if(!veh)return <Loading/>;
  if(!veh.vehicles.length)return <div className="card"><h2>Add a vehicle first</h2><p className="mut">You need a registered vehicle to book a slot.</p><button className="btn" style={{marginTop:14}} onClick={()=>go('vehicles')}>Add vehicle</button></div>;
  const shown=sl?sl.slots.filter(s=>f.floor==='any'||String(s.floor)===f.floor):[];
  return <div className="stack"><Head t="Find parking" p="Choose a time and we'll show the slots free for that exact window."/>
    <div className="card"><div className="fgrid"><Fld l="Vehicle"><select {...bind(f,setF,'plate')}>{veh.vehicles.map(x=><option key={x.id} value={x.plate}>{x.plate} · {x.type}</option>)}</select></Fld><Fld l="Location"><select value={f.floor} onChange={e=>setF(p=>({...p,floor:e.target.value,slot:''}))}><option value="any">Any floor</option>{sl?.floors.map(x=><option key={x} value={x}>Floor {x}</option>)}</select></Fld><Fld l="Date"><input type="date" {...bind(f,setF,'date')}/></Fld><Fld l="Entry time"><input type="time" {...bind(f,setF,'t1')}/></Fld><Fld l="Expected exit"><input type="time" {...bind(f,setF,'t2')}/></Fld></div></div>
    <div className="card"><div className="row" style={{marginBottom:14}}><h2 style={{margin:0}}>Slots</h2><Legend/></div>{!sl?<Skel h={160}/>:<div className="sgrid">{shown.map(s=><SlotCard key={s.id} s={valid&&s.free?{...s,status:'AVAILABLE'}:s} na={!s.free} sel={f.slot===s.id} onClick={()=>s.free&&setF(p=>({...p,slot:p.slot===s.id?'':s.id}))}/>)}</div>}<p className="mut" style={{marginTop:14,fontSize:14}}>{f.slot?`Slot ${f.slot} selected.`:'No slot selected: we will auto-allocate the best match.'}</p></div>
    <div className="card row"><div className="grow"><h3>Estimated fee</h3><p className="mut">{q?`${q.billableHours} h × ${$(q.hourly+q.charging)}/h`:'Choose a valid time window'}</p></div><b style={{fontSize:30}}>{q?$(q.total):'—'}</b><button className="btn" disabled={!valid||busy} onClick={book}>{busy?'Booking…':'Book slot'}</button></div>
    {done&&<Modal title="Booking confirmed" onClose={()=>setDone(null)}><dl className="kv"><dt>Booking ID</dt><dd>{done.id}</dd><dt>Slot</dt><dd>{done.slot} · Floor {done.floor}</dd><dt>Vehicle</dt><dd>{done.plate}</dd><dt>Entry</dt><dd>{T(done.start)}</dd><dt>Exit</dt><dd>{T(done.end)}</dd><dt>Status</dt><dd><Badge s={done.status}/></dd></dl>{done.status==='PENDING'&&<p className="mut">This lot approves bookings manually. You'll see the status update here.</p>}<button className="btn" onClick={()=>{setDone(null);go('bookings')}}>View my bookings</button></Modal>}
  </div>;
}
function MyBookings(){
  const [d,reload,e]=useData('/api/bookings',{},8000),[tab,setTab]=useState('upcoming');
  if(!d)return <Loading e={e}/>;
  const tabs={upcoming:x=>x.status==='BOOKED'||x.status==='PENDING'||x.status==='ACTIVE',history:x=>x.status==='COMPLETED',cancelled:x=>x.status==='CANCELLED'||x.status==='REJECTED'};
  const run=(p,body,msg,sure)=>async()=>{if(sure&&!await ask(sure,true))return;await act(()=>POST(p,body),msg);reload()};
  return <div className="stack"><Head t="My bookings"><div className="seg">{Object.keys(tabs).map(k=><button key={k} className={tab===k?'on':''} onClick={()=>setTab(k)}>{k[0].toUpperCase()+k.slice(1)}</button>)}</div></Head>
    <div className="card"><Table cols={[['Booking',r=>r.id],['Vehicle',r=>r.plate],['Slot',r=>r.slot+' · F'+r.floor],['Entry',r=>T(r.start)],['Exit',r=>T(r.end)],['Fee',r=>r.status==='COMPLETED'?$(r.fee):'—'],['Status',r=><Badge s={r.status}/>],['',r=><div className="row" style={{gap:6}}>
      {r.status==='BOOKED'&&<button className="btn xs ghost" onClick={run('/api/checkin',{id:r.id},'Checked in')}>Simulate entry</button>}
      {r.status==='ACTIVE'&&<button className="btn xs" onClick={run('/api/checkout',{id:r.id},'Checked out')}>Check out</button>}
      {(r.status==='BOOKED'||r.status==='PENDING')&&r.start>Date.now()/1000&&<button className="btn xs danger" onClick={run('/api/cancel',{id:r.id},'Booking cancelled',`Cancel booking ${r.id}? The slot will open up again.`)}>Cancel</button>}</div>]]} rows={d.bookings.filter(tabs[tab])} empty={tab==='cancelled'?'No cancellations.':'No bookings in this view.'}/></div></div>;
}
function MyVehicles(){
  const [d,reload,e]=useData('/api/vehicles'),[m,setM]=useState(null),[f,setF]=useState({});
  if(!d)return <Loading e={e}/>;
  const open=v=>{setF(v||{type:'CAR',plate:'',model:''});setM(v?'edit':'add')};
  const save=async()=>{const r=await act(()=>POST(m==='add'?'/api/vehicles/add':'/api/vehicles/edit',f),m==='add'?'Vehicle added':'Vehicle updated');if(r){setM(null);reload()}};
  const del=async v=>{if(!await ask(`Remove ${v.plate}?`,true))return;if(await act(()=>POST('/api/vehicles/delete',{id:v.id}),'Vehicle removed'))reload()};
  return <div className="stack"><Head t="My vehicles" p="Cars, bikes and electric vehicles."><button className="btn" onClick={()=>open()}>Add vehicle</button></Head>
    <div className="cards">{d.vehicles.map(v=><div key={v.id} className="card stack" style={{gap:8}}><Icon n="car" s={26}/><h3>{v.plate}</h3><span className="mut">{v.model||'No model set'} · {v.type==='EV'?'Electric':v.type[0]+v.type.slice(1).toLowerCase()}</span>{v.slot&&<Badge s={'Parked in '+v.slot}/>}<div className="row"><button className="btn xs ghost" onClick={()=>open(v)}>Edit</button><button className="btn xs danger" onClick={()=>del(v)}>Delete</button></div></div>)}{!d.vehicles.length&&<div className="card mut">No vehicles yet. Add your first one.</div>}</div>
    {m&&<Modal title={m==='add'?'Add vehicle':'Edit vehicle'} onClose={()=>setM(null)}><Fld l="Registration number"><input {...bind(f,setF,'plate')} placeholder="TN09AB1234"/></Fld><Fld l="Vehicle type"><select {...bind(f,setF,'type')}><option value="CAR">Car</option><option value="BIKE">Bike</option><option value="EV">Electric Vehicle</option></select></Fld><Fld l="Model (optional)"><input {...bind(f,setF,'model')}/></Fld><button className="btn" onClick={save}>{m==='add'?'Add vehicle':'Save changes'}</button></Modal>}</div>;
}
function Tracking({go}){
  const [d,reload,e]=useData('/api/bookings',{},4000),[sim,setSim]=useState('');
  if(!d)return <Loading e={e}/>;
  const a=d.bookings.find(x=>x.status==='ACTIVE'),nx=d.bookings.filter(x=>x.status==='BOOKED').sort((x,y)=>x.start-y.start)[0];
  const out=async()=>{const r=await act(()=>POST('/api/checkout',{id:a.id,sim_minutes:sim||0}),'Checked out');if(r)reload()};
  return <div className="stack"><Head t="Vehicle tracking" p="Entry and exit are simulated: no sensors needed."/>
    {a?<div className="two"><div className="card"><h2>{a.plate} is parked</h2><dl className="kv"><dt>Assigned slot</dt><dd>{a.slot} · Floor {a.floor}</dd><dt>Entry time</dt><dd>{T(a.entry)}</dd><dt>Expected exit</dt><dd>{T(a.end)}</dd><dt>Status</dt><dd><Badge s="ACTIVE"/></dd></dl></div>
      <div className="card"><h2>Live fee</h2><dl className="kv"><dt>Duration</dt><dd>{dur(a.quote.minutes)}</dd><dt>Billed hours</dt><dd>{a.quote.billableHours}</dd><dt>Hourly rate</dt><dd>{$(a.quote.hourly)}{a.quote.charging?` + ${$(a.quote.charging)} charging`:''}</dd><dt>Overstay charge</dt><dd>{$(a.quote.overstay)}</dd><dt>Total so far</dt><dd style={{fontSize:22}}>{$(a.quote.total)}</dd></dl><div className="row" style={{marginTop:18}}><Fld l="Simulate parked minutes"><input type="number" min="0" value={sim} onChange={e=>setSim(e.target.value)} placeholder="e.g. 90"/></Fld><button className="btn" onClick={out}>Check out</button></div></div></div>
    :<div className="card"><h2>No active session</h2><p className="mut">{nx?`Next up: ${nx.plate} in slot ${nx.slot} at ${T(nx.start)}.`:'Book a slot to start.'}</p>{nx?<button className="btn" style={{marginTop:14}} onClick={async()=>{if(await act(()=>POST('/api/checkin',{id:nx.id}),'Vehicle entered'))reload()}}>Simulate entry</button>:<button className="btn" style={{marginTop:14}} onClick={()=>go('find')}>Find parking</button>}</div>}</div>;
}
function Payments(){
  const [p]=useData('/api/payments'),[r]=useData('/api/rates');if(!p||!r)return <Loading/>;
  return <div className="stack"><Head t="Payments"/><div className="cards"><Stat label="Total spent" value={$(p.total)}/><Stat label="Car" value={$(r.car)+'/h'}/><Stat label="Bike" value={$(r.bike)+'/h'}/><Stat label="Electric" value={$(r.ev+r.evCharge)+'/h'} sub={`incl. ${$(r.evCharge)} charging`}/></div><p className="mut">Billed in 15-minute blocks. Staying past your expected exit adds {r.overstayPct}% of the hourly rate for the extra time.</p>
    <div className="card"><Table cols={[['Payment',x=>x.id],['Booking',x=>x.booking],['Vehicle',x=>x.plate],['Paid',x=>T(x.time)],['Amount',x=><b>{$(x.amount)}</b>]]} rows={p.payments} empty="No payments yet. Fees appear after you check out."/></div></div>;
}
function CReports(){
  const [d]=useData('/api/bookings');if(!d)return <Loading/>;
  const done=d.bookings.filter(b=>b.status==='COMPLETED'),by=(k)=>{const m={};done.forEach(b=>{const x=k(b);m[x]=m[x]||{n:0,s:0};m[x].n++;m[x].s+=b.fee});return Object.entries(m)};
  const month=by(b=>{const t=new Date(b.exit*1000);return t.getFullYear()+'-'+pad(t.getMonth()+1)}).sort(),veh=by(b=>b.plate);
  return <div className="stack"><Head t="Reports"><button className="btn ghost sm" onClick={()=>csv([['Booking','Vehicle','Slot','Entry','Exit','Fee','Status'],...d.bookings.map(b=>[b.id,b.plate,b.slot,T(b.start),T(b.end),b.fee,b.status])],'my-bookings.csv')}>Export CSV</button></Head>
    <div className="two"><div className="card"><h2>Monthly parking summary</h2><BarChart money data={month.map(([k,v])=>({x:k.slice(2),y:v.s}))}/><Table cols={[['Month',r=>r[0]],['Sessions',r=>r[1].n],['Spent',r=>$(r[1].s)]]} rows={month}/></div>
    <div className="card"><h2>Vehicle usage</h2><Table cols={[['Vehicle',r=>r[0]],['Sessions',r=>r[1].n],['Spent',r=>$(r[1].s)]]} rows={veh}/></div></div>
    <div className="card"><h2>Booking history</h2><Table cols={[['Booking',r=>r.id],['Vehicle',r=>r.plate],['Entry',r=>T(r.entry||r.start)],['Exit',r=>T(r.exit||r.end)],['Fee',r=>r.status==='COMPLETED'?$(r.fee):'—'],['Status',r=><Badge s={r.status}/>]]} rows={d.bookings}/></div></div>;
}
function Profile(){
  const [f,setF]=useState({name:auth.user.name,phone:auth.user.phone});
  const save=async()=>{const r=await act(()=>POST('/api/profile',f),'Profile saved');if(r)auth.set(auth.token,auth.role,r)};
  return <div className="stack"><Head t="Profile"/><div className="card stack" style={{maxWidth:520}}><dl className="kv"><dt>User ID</dt><dd>{auth.user.id}</dd><dt>Email</dt><dd>{auth.user.email}</dd></dl><Fld l="Full name"><input {...bind(f,setF,'name')}/></Fld><Fld l="Phone"><input {...bind(f,setF,'phone')}/></Fld><button className="btn" onClick={save}>Save changes</button></div></div>;
}

/* ---------- admin pages ---------- */
function AOverview(){
  const [o,,e]=useData('/api/admin/overview',{},6000);if(!o)return <Loading e={e}/>;
  return <div className="stack"><Head t="Overview" p="Live status of the whole lot."/>
    <div className="cards"><Stat label="Total slots" value={o.total}/><Stat label="Available" value={o.available}/><Stat label="Occupied" value={o.occupied}/><Stat label="Reserved" value={o.reserved}/><Stat label="Customers" value={o.customers}/><Stat label="Vehicles" value={o.vehicles}/><Stat label="Active sessions" value={o.active}/><Stat label="Total revenue" value={$(o.revenue)}/><Stat label="Occupancy" value={o.occupancy+'%'}/></div>
    <div className="two"><div className="card"><h2>Slot status</h2><Donut parts={[{k:'Available',v:o.available,c:SC.AVAILABLE},{k:'Occupied',v:o.occupied,c:SC.OCCUPIED},{k:'Reserved',v:o.reserved,c:SC.RESERVED},{k:'Disabled',v:o.disabled,c:SC.DISABLED}]}/></div><div className="card"><h2>Revenue, last 7 days</h2><BarChart money data={o.revenue7}/></div></div></div>;
}
function SlotModal({s,close,reload}){
  const [pl,setPl]=useState(''),i=s.info,run=async(st,m)=>{if(await act(()=>POST('/api/admin/slot/status',{id:s.id,status:st,vehicle:pl}),m)){close();reload()}};
  return <Modal title={'Slot '+s.id} onClose={close}><dl className="kv"><dt>Status</dt><dd><Badge s={s.status}/></dd><dt>Type · Floor</dt><dd>{s.type} · {s.floor}</dd><dt>Vehicle number</dt><dd>{i?.plate||s.vehicle||'—'}</dd><dt>Vehicle type</dt><dd>{i?.vtype||'—'}</dd><dt>Customer</dt><dd>{i?.customer||'—'}</dd><dt>Booking ID</dt><dd>{i?.id||'—'}</dd><dt>Entry time</dt><dd>{i?T(i.entry||i.start):'—'}</dd><dt>Expected exit</dt><dd>{i?T(i.end):'—'}</dd><dt>Parking duration</dt><dd>{i?dur(i.quote.minutes):'—'}</dd><dt>Fee</dt><dd>{i?$(i.quote.total):'—'}</dd></dl>
    {s.status==='AVAILABLE'&&<><Fld l="Vehicle number (manual allocation)"><input value={pl} onChange={e=>setPl(e.target.value)} placeholder="TN09AB1234"/></Fld><button className="btn" onClick={()=>run('OCCUPIED','Slot allocated')}>Allocate manually</button></>}
    {(s.status==='OCCUPIED'||s.status==='RESERVED'||s.status==='DISABLED')&&<button className="btn" onClick={()=>run('AVAILABLE',s.status==='DISABLED'?'Slot enabled':'Slot released')}>{s.status==='DISABLED'?'Enable slot':'Release slot'}</button>}
    {s.status!=='DISABLED'&&<button className="btn ghost" onClick={()=>run('DISABLED','Slot disabled')}>Disable temporarily</button>}</Modal>;
}
function ALive(){
  const [d,reload,e]=useData('/api/admin/slots',{},4000),[sel,setSel]=useState(null);if(!d)return <Loading e={e}/>;
  const floors=[...new Set(d.slots.map(s=>s.floor))].sort(),cur=sel&&d.slots.find(s=>s.id===sel);
  return <div className="stack"><Head t="Live parking" p="Click any slot to inspect or control it."><Legend/></Head>{floors.map(f=><div key={f} className="card floor"><h3>Floor {f}</h3><div className="sgrid">{d.slots.filter(s=>s.floor===f).map(s=><SlotCard key={s.id} s={s} onClick={()=>setSel(s.id)}/>)}</div></div>)}{cur&&<SlotModal s={cur} close={()=>setSel(null)} reload={reload}/>}</div>;
}
function ASlots(){
  const [d,reload,e]=useData('/api/admin/slots'),[m,setM]=useState(null),[f,setF]=useState({});if(!d)return <Loading e={e}/>;
  const open=s=>{setF(s?{...s}:{type:'CAR',floor:0,types:'CAR'});setM(s?'edit':'add')};
  const tg=t=>{const a=(f.types||'').split('+').filter(Boolean);setF(p=>({...p,types:(a.includes(t)?a.filter(x=>x!==t):[...a,t]).join('+')}))};
  const save=async()=>{if(await act(()=>POST(m==='add'?'/api/admin/slot/add':'/api/admin/slot/edit',f),'Slot saved')){setM(null);reload()}};
  const st=async(s,v)=>{if(await act(()=>POST('/api/admin/slot/status',{id:s.id,status:v}),'Slot updated'))reload()};
  const del=async s=>{if(!await ask(`Delete slot ${s.id}?`,true))return;if(await act(()=>POST('/api/admin/slot/delete',{id:s.id}),'Slot deleted'))reload()};
  return <div className="stack"><Head t="Slot management"><button className="btn" onClick={()=>open()}>Add slot</button></Head><div className="card"><Table cols={[['Slot',s=><b>{s.id}</b>],['Category',s=>s.type==='EV'?'EV Parking':s.type[0]+s.type.slice(1).toLowerCase()+' Parking'],['Floor',s=>s.floor],['Supports',s=>s.types.replace(/\+/g,', ')],['Status',s=><Badge s={s.status}/>],['Vehicle',s=>s.vehicle||'—'],['Booking',s=>s.info?.id||'—'],['',s=><div className="row" style={{gap:6}}><select className="search" style={{padding:'5px 10px',minWidth:0}} value="" onChange={e=>e.target.value&&st(s,e.target.value)}><option value="">Set status…</option><option value="AVAILABLE">Available</option><option value="OCCUPIED">Occupied</option><option value="RESERVED">Reserved</option><option value="DISABLED">Disabled</option></select><button className="btn xs ghost" onClick={()=>open(s)}>Edit</button><button className="btn xs danger" onClick={()=>del(s)}>Delete</button></div>]]} rows={d.slots}/></div>
    {m&&<Modal title={m==='add'?'Add slot':'Edit '+f.id} onClose={()=>setM(null)}><Fld l="Category"><select {...bind(f,setF,'type')}><option value="CAR">Car parking</option><option value="BIKE">Bike parking</option><option value="EV">EV parking</option></select></Fld><Fld l="Floor"><input type="number" min="0" max="20" {...bind(f,setF,'floor')}/></Fld><div className="stack" style={{gap:8}}><span className="mut" style={{fontSize:13}}>Compatible vehicles</span><div className="row">{['CAR','BIKE','EV'].map(t=><label key={t} className="row" style={{gap:6}}><input type="checkbox" checked={(f.types||'').includes(t)} onChange={()=>tg(t)}/>{t}</label>)}</div></div><button className="btn" onClick={save}>Save slot</button></Modal>}</div>;
}
function AVehicles(){
  const [d,,e]=useData('/api/admin/vehicles',{},8000),[q,setQ]=useState(''),[t,setT]=useState('ALL'),[h,setH]=useState(null),[hb]=useData(h?'/api/admin/bookings':null,h?{plate:h}:{});
  if(!d)return <Loading e={e}/>;const rows=d.vehicles.filter(v=>(t==='ALL'||v.type===t)&&v.plate.includes(q.toUpperCase().replace(/\W/g,'')));
  return <div className="stack"><Head t="Vehicle management"><input className="search" placeholder="Search vehicle number" value={q} onChange={e=>setQ(e.target.value)}/><div className="seg">{['ALL','CAR','BIKE','EV'].map(k=><button key={k} className={t===k?'on':''} onClick={()=>setT(k)}>{k==='ALL'?'All':k==='EV'?'EV':k[0]+k.slice(1).toLowerCase()}</button>)}</div></Head>
    <div className="card"><Table cols={[['Vehicle',v=><b>{v.plate}</b>],['Type',v=>v.type],['Model',v=>v.model||'—'],['Owner',v=>v.ownerName],['Current location',v=>v.slot?<Badge s={'Slot '+v.slot}/>:'Not parked'],['Sessions',v=>v.trips],['',v=><button className="btn xs ghost" onClick={()=>setH(v.plate)}>History</button>]]} rows={rows}/></div>
    {h&&<Modal wide title={'History · '+h} onClose={()=>setH(null)}>{!hb?<Skel h={160}/>:<Table cols={[['Booking',r=>r.id],['Slot',r=>r.slot],['Entry',r=>T(r.entry||r.start)],['Exit',r=>r.exit?T(r.exit):'—'],['Fee',r=>r.status==='COMPLETED'?$(r.fee):'—'],['Status',r=><Badge s={r.status}/>]]} rows={hb.bookings}/>}</Modal>}</div>;
}
function ACustomers(){
  const [d,reload,e]=useData('/api/admin/customers',{},8000),[q,setQ]=useState(''),[v,setV]=useState(null),[dt]=useData(v?'/api/admin/customer':null,v?{id:v}:{});
  if(!d)return <Loading e={e}/>;const rows=d.customers.filter(c=>(c.name+c.email+c.id).toLowerCase().includes(q.toLowerCase()));
  const block=async c=>{if(!await ask(`${c.blocked?'Unblock':'Block'} ${c.name}?`,!c.blocked))return;if(await act(()=>POST('/api/admin/customer/block',{id:c.id,blocked:c.blocked?0:1}),c.blocked?'Account unblocked':'Account blocked'))reload()};
  return <div className="stack"><Head t="Customer management"><input className="search" placeholder="Search customers" value={q} onChange={e=>setQ(e.target.value)}/></Head>
    <div className="card"><Table cols={[['ID',c=>c.id],['Name',c=><b>{c.name}</b>],['Email',c=>c.email],['Vehicles',c=>c.vehicles],['Bookings',c=>c.bookings],['Spent',c=>$(c.spent)],['Account',c=>c.blocked?<Badge s="Cancelled"/>:<Badge s="Active"/>],['',c=><div className="row" style={{gap:6}}><button className="btn xs ghost" onClick={()=>setV(c.id)}>View</button><button className={'btn xs '+(c.blocked?'':'danger')} onClick={()=>block(c)}>{c.blocked?'Unblock':'Block'}</button></div>]]} rows={rows}/></div>
    {v&&<Modal wide title={dt?.user.name||'Customer'} onClose={()=>setV(null)}>{!dt?<Skel h={200}/>:<><div className="cards"><Stat label="Total spent" value={$(dt.spent)}/><Stat label="Vehicles" value={dt.vehicles.length}/><Stat label="Bookings" value={dt.bookings.length}/></div><p>{dt.vehicles.map(x=>x.plate+' ('+x.type+')').join(' · ')||'No vehicles'}</p><Table cols={[['Booking',r=>r.id],['Vehicle',r=>r.plate],['Entry',r=>T(r.start)],['Fee',r=>r.status==='COMPLETED'?$(r.fee):'—'],['Status',r=><Badge s={r.status}/>]]} rows={dt.bookings.slice(0,30)}/></>}</Modal>}</div>;
}
function ABookings(){
  const [d,reload,e]=useData('/api/admin/bookings',{},6000),[sl]=useData('/api/admin/slots'),[q,setQ]=useState(''),[s,setS]=useState('ALL'),[m,setM]=useState(null),[f,setF]=useState({});
  if(!d||!sl)return <Loading e={e}/>;
  const rows=d.bookings.filter(b=>(s==='ALL'||b.status===s)&&(b.id+b.plate+b.customer).toLowerCase().includes(q.toLowerCase()));
  const run=(p,b,msg,sure)=>async()=>{if(sure&&!await ask(sure,true))return;if(await act(()=>POST(p,b),msg))reload()};
  const open=b=>{setF({id:b.id,slot:b.slot,start:toIn(b.start),end:toIn(b.end),vtype:b.vtype});setM(b)};
  const save=async()=>{if(await act(()=>POST('/api/admin/booking/modify',{id:f.id,slot:f.slot,start:fromIn(f.start),end:fromIn(f.end)}),'Booking updated')){setM(null);reload()}};
  return <div className="stack"><Head t="Booking management"><input className="search" placeholder="Search bookings" value={q} onChange={e=>setQ(e.target.value)}/><select className="search" value={s} onChange={e=>setS(e.target.value)}>{['ALL','PENDING','BOOKED','ACTIVE','COMPLETED','CANCELLED','REJECTED'].map(x=><option key={x}>{x}</option>)}</select></Head>
    <div className="card"><Table cols={[['Booking',b=><b>{b.id}</b>],['Customer',b=>b.customer],['Vehicle',b=>b.plate],['Slot',b=>b.slot],['Entry',b=>T(b.start)],['Exit',b=>T(b.end)],['Status',b=><Badge s={b.status}/>],['',b=><div className="row" style={{gap:6}}>
      {b.status==='PENDING'&&<><button className="btn xs" onClick={run('/api/admin/booking/approve',{id:b.id},'Approved')}>Approve</button><button className="btn xs ghost" onClick={run('/api/admin/booking/reject',{id:b.id},'Rejected')}>Reject</button></>}
      {(b.status==='BOOKED'||b.status==='PENDING')&&<><button className="btn xs ghost" onClick={()=>open(b)}>Modify</button><button className="btn xs ghost" onClick={run('/api/admin/booking/checkin',{id:b.id},'Vehicle entered')}>Entry</button><button className="btn xs danger" onClick={run('/api/admin/booking/cancel',{id:b.id},'Booking cancelled',`Cancel ${b.id}?`)}>Cancel</button></>}
      {b.status==='ACTIVE'&&<button className="btn xs" onClick={run('/api/admin/booking/checkout',{id:b.id},'Checked out')}>Exit</button>}</div>]]} rows={rows}/></div>
    {m&&<Modal title={'Modify '+f.id} onClose={()=>setM(null)}><Fld l="Slot"><select {...bind(f,setF,'slot')}>{sl.slots.filter(x=>x.types.includes(f.vtype)).map(x=><option key={x.id} value={x.id}>{x.id} · Floor {x.floor}</option>)}</select></Fld><Fld l="Entry"><input type="datetime-local" {...bind(f,setF,'start')}/></Fld><Fld l="Exit"><input type="datetime-local" {...bind(f,setF,'end')}/></Fld><button className="btn" onClick={save}>Save changes</button></Modal>}</div>;
}
function AFees(){
  const [r,reload,e]=useData('/api/rates'),[p]=useData('/api/admin/payments',{},10000),[f,setF]=useState(null);
  useEffect(()=>{if(r)setF({...r})},[r]);if(!r||!p||!f)return <Loading e={e}/>;
  const save=async()=>{if(await act(()=>POST('/api/admin/rates',f),'Rates saved'))reload()};
  return <div className="stack"><Head t="Fees & payments"/><div className="card"><h2>Hourly rates</h2><div className="fgrid">{[['car','Car (₹/h)'],['bike','Bike (₹/h)'],['ev','EV (₹/h)'],['evCharge','EV charging add-on (₹/h)'],['overstayPct','Overstay surcharge (%)']].map(([k,l])=><Fld key={k} l={l}><input type="number" min="0" {...bind(f,setF,k)}/></Fld>)}</div><button className="btn" style={{marginTop:18}} onClick={save}>Save rates</button></div>
    <div className="cards"><Stat label="Total revenue" value={$(p.total)}/><Stat label="Payments" value={p.payments.length}/></div>
    <div className="card"><h2>Payment history</h2><Table cols={[['Payment',x=>x.id],['Booking',x=>x.booking],['Customer',x=>x.customer],['Vehicle',x=>x.plate],['Paid',x=>T(x.time)],['Amount',x=><b>{$(x.amount)}</b>]]} rows={p.payments.slice(0,100)}/></div></div>;
}
function AAnalytics(){
  const [d,,e]=useData('/api/admin/predict',{},30000);if(!d)return <Loading e={e}/>;
  const lab=h=>pad(h)+':00',fc=d.hours.map((h,i)=>({x:lab(h),y:d.pct[i]})),av=d.hours.map((h,i)=>({x:lab(h),y:d.available[i]}));
  return <div className="stack"><Head t="Occupancy analytics" p="Forecast from past bookings, current load, time of day and weekday."/>
    <div className="cards"><Stat label="Occupancy now" value={d.current+'%'}/><Stat label="Peak hours" value={d.peak.map(lab).join(', ')} sub="highest expected demand"/><Stat label="Next-hour expected free" value={d.available[1]} sub={`of ${d.total} slots`}/></div>
    <div className="card"><h2>Expected occupancy, next 24 hours</h2><LineChart data={fc}/></div>
    <div className="two"><div className="card"><h2>Expected available slots</h2><BarChart data={av}/></div><div className="card"><h2>Typical day (historical average)</h2><LineChart data={d.profile.map((y,h)=>({x:lab(h),y}))}/></div></div></div>;
}
function AReports(){
  const R=[['daily','Daily parking report'],['weekly','Weekly parking report'],['monthly','Monthly parking report'],['revenue','Revenue report'],['entryexit','Vehicle entry/exit report'],['occupancy','Parking occupancy report'],['cancellations','Booking cancellation report']],[b,setB]=useState('');
  const dl=async t=>{setB(t);const x=await act(()=>GET('/api/admin/report',{type:t}));setB('');if(!x)return;const a=document.createElement('a');a.href=URL.createObjectURL(x);a.download=`smartpark-${t}.csv`;a.click();toast('Report downloaded')};
  return <div className="stack"><Head t="Reports" p="Every report exports as a CSV file."/><div className="cards">{R.map(([k,l])=><div key={k} className="card stack" style={{gap:12}}><Icon n="file" s={26}/><h3>{l}</h3><button className="btn sm" disabled={b===k} onClick={()=>dl(k)}>{b===k?'Preparing…':'Export CSV'}</button></div>)}</div></div>;
}
function ASettings(){
  const [r,reload,e]=useData('/api/rates');if(!r)return <Loading e={e}/>;
  const tg=async()=>{if(await act(()=>POST('/api/admin/rates',{manualApproval:r.manualApproval?0:1}),'Setting saved'))reload()};
  const bk=()=>act(()=>POST('/api/admin/backup'),'Backup created');
  return <div className="stack"><Head t="Settings"/><div className="card row"><div className="grow"><h3>Manual booking approval</h3><p className="mut">New bookings wait as Pending until you approve them.</p></div><button className={'btn '+(r.manualApproval?'':'ghost')} onClick={tg}>{r.manualApproval?'On':'Off'}</button></div>
    <div className="card row"><div className="grow"><h3>Data backup</h3><p className="mut">Snapshots are also taken automatically every hour and on shutdown (last 10 kept).</p></div><button className="btn ghost" onClick={bk}>Back up now</button></div></div>;
}

/* ---------- shell & router ---------- */
const CNAV=[['dashboard','Dashboard','home'],['find','Find Parking','search'],['bookings','My Bookings','cal'],['vehicles','My Vehicles','car'],['tracking','Vehicle Tracking','pin'],['payments','Payments','card'],['reports','Reports','chart'],['profile','Profile','user']];
const ANAV=[['overview','Overview','home'],['live','Live Parking','grid'],['slots','Slot Management','pin'],['vehicles','Vehicle Management','car'],['customers','Customer Management','user'],['bookings','Booking Management','cal'],['fees','Fee Management','card'],['analytics','Occupancy Analytics','chart'],['reports','Reports','file'],['settings','Settings','gear']];
const CP={dashboard:Dash,find:Find,bookings:MyBookings,vehicles:MyVehicles,tracking:Tracking,payments:Payments,reports:CReports,profile:Profile};
const AP={overview:AOverview,live:ALive,slots:ASlots,vehicles:AVehicles,customers:ACustomers,bookings:ABookings,fees:AFees,analytics:AAnalytics,reports:AReports,settings:ASettings};
function Shell({kind,page}){
  const adm=kind==='admin',nav=adm?ANAV:CNAV,base=adm?'#/console/':'#/portal/',Page=(adm?AP:CP)[page]||(adm?AOverview:Dash),[open,setOpen]=useState(false);
  const go=p=>{location.hash=base+p;setOpen(false)};
  const out=async()=>{await POST('/api/logout').catch(()=>{});auth.clear();location.hash='#/'};
  return <div className="shell"><aside className={'side glass'+(open?' open':'')}><div className="logo"><i>P</i>SmartPark{adm&&<span className="badge" style={{marginLeft:4}}>Admin</span>}</div>
    {nav.map(n=><button key={n[0]} className={'nav'+(page===n[0]?' on':'')} onClick={()=>go(n[0])}><Icon n={n[2]}/>{n[1]}</button>)}<button className="nav" style={{marginTop:'auto'}} onClick={out}><Icon n="out"/>Logout</button></aside>
    <main className="main"><button className="btn ghost sm burger" style={{marginBottom:16}} onClick={()=>setOpen(!open)} aria-label="Menu"><Icon n="menu"/></button><div className="view" key={page}><Page go={go}/></div></main></div>;
}
function Redirect({to}){useEffect(()=>{location.hash=to},[]);return null}
class Boundary extends React.Component{state={e:null};static getDerivedStateFromError(e){return{e}}render(){return this.state.e?<div className="auth"><div className="card"><h1>Something went wrong</h1><p className="mut">{String(this.state.e.message||this.state.e)}</p><button className="btn" onClick={()=>{this.setState({e:null});location.hash='#/'}}>Back to home</button></div></div>:this.props.children}}
function App(){
  const [h,setH]=useState(location.hash.slice(1)||'/');
  useEffect(()=>{const f=()=>{setH(location.hash.slice(1)||'/');scrollTo(0,0)};addEventListener('hashchange',f);return()=>removeEventListener('hashchange',f)},[]);
  const [r1,r2]=h.split('/').filter(Boolean);let v;
  if(r1==='portal')v=auth.role==='customer'?<Shell kind="customer" page={r2||'dashboard'}/>:<Redirect to="#/login"/>;
  else if(r1==='console')v=auth.role==='admin'?<Shell kind="admin" page={r2||'overview'}/>:<Redirect to="#/admin"/>;
  else if(r1==='login')v=<AuthCard/>;else if(r1==='admin')v=<AuthCard admin/>;else v=<Landing/>;
  return <Boundary><div key={r1||'home'} className="page">{v}</div><Toasts/><Confirm/><Offline/></Boundary>;
}
ReactDOM.createRoot(document.getElementById('root')).render(<App/>);
